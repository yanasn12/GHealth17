package controllers;

public class ClinicWeeklyReport {

	public static void main(String[] args) {
	

	}

}
