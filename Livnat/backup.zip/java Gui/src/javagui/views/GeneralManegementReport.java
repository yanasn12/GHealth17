package javagui.views;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Color;

import javax.swing.ImageIcon;

import java.awt.Toolkit;

import javax.swing.JButton;

import java.awt.Font;

import javax.swing.SwingConstants;
import javax.swing.JDesktopPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;

import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.JTextField;

import Entitys.Daily_Report_Entity;
import controllers.ClinicWeeklyReport;
import controllers.DailyReportController;
import javax.swing.border.TitledBorder;
import javax.swing.UIManager;
import javax.swing.JToggleButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class GeneralManegementReport extends JFrame {
//	public Daily_Report_Entity dailyRepEnt = new Daily_Report_Entity();
	
	private JPanel contentPane;
	private JDesktopPane desktopReports;
	private JButton btnViewMonthlyReport;
	private TypeOfMonthlyReports Rep;
	public WeeklyReport WeekRep;
	private JButton button;
	private JTextField dateField;
	private JPanel DailyPanel;
	private JLabel lblPatientAmount;
	private String inputQuery;
	private JLabel label_5;
	private JTable table;
	private JLabel lblDays;
	private JLabel lblDays_1;
	private JLabel lblDays_2;
	private JLabel lblDays_3;
	private JLabel lblWaitingTime;
	private JLabel lbl0;
	private JLabel lbl31;
	private JLabel lbl61;
	private JLabel lbl91p;
	private JLabel lblNewLabel_2;
	//////////////////private MonthlyReports Rep;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GeneralManegementReport frame = new GeneralManegementReport();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GeneralManegementReport() {
		initComponent(); //// ����� �� INIT ��� �� �� �� ������ ��������
		createEvents1();/// ����� ������- ���� ����
		createEvents2();
		//createEvents3();
	}
	///////// init component of desktop reports
	private void initComponent() {
		//	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	//	setBounds(0, 0, 810, 775);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(GeneralManegementReport.class.getResource("/javagui/resources/GHealthlogo.png")));
		label.setBounds(113, 25, 242, 68);
		contentPane.add(label);
		
		button = new JButton("View weekly reports");//////////////////////////////////////////////////////////////////////////
		
		
		
		button.setIcon(new ImageIcon(GeneralManegementReport.class.getResource("/javagui/resources/img16x16/reports.png")));
		button.setHorizontalAlignment(SwingConstants.LEFT);
		button.setForeground(Color.BLUE);
		button.setFont(new Font("Tahoma", Font.BOLD, 11));
		button.setBackground(Color.WHITE);
		button.setBounds(10, 133, 192, 39);
		contentPane.add(button);
		
		btnViewMonthlyReport = new JButton("View monthly report ");
		
		btnViewMonthlyReport.setIcon(new ImageIcon(GeneralManegementReport.class.getResource("/javagui/resources/img16x16/reports.png")));
		btnViewMonthlyReport.setHorizontalAlignment(SwingConstants.LEFT);
		btnViewMonthlyReport.setForeground(Color.BLUE);
		btnViewMonthlyReport.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnViewMonthlyReport.setBackground(Color.WHITE);
		btnViewMonthlyReport.setBounds(10, 183, 192, 39);
		contentPane.add(btnViewMonthlyReport);
		
		desktopReports = new JDesktopPane();
		desktopReports.setBackground(Color.WHITE);
		desktopReports.setBounds(212, 133, 621, 596);
		contentPane.add(desktopReports);
		desktopReports.setLayout(null);
		
		DailyPanel = new JPanel();
		DailyPanel.setBounds(0, 0, 499, 490);
		desktopReports.add(DailyPanel);
		
		JLabel lblNewLabel = new JLabel("Daily-Report");
		lblNewLabel.setBounds(188, 11, 133, 35);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));
		DailyPanel.setVisible(false);
		DailyPanel.setLayout(null);
		DailyPanel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Choose date:");
		lblNewLabel_1.setBounds(24, 67, 110, 28);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		DailyPanel.add(lblNewLabel_1);
		
		dateField = new JTextField();
		dateField.setBounds(132, 67, 110, 28);
		dateField.setFont(new Font("Tahoma", Font.PLAIN, 14));
		Date dt = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");// HH:mm");
		dateField.setText(sdf.format(dt));
		DailyPanel.add(dateField);
		dateField.setColumns(10);
		
		JButton btnNewButton = new JButton("Calc");
		btnNewButton.setBounds(252, 67, 89, 28);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int dVal;
				
				inputQuery="pullbykey:appointments:app_date,"+dateField.getText();
				inputQuery=inputQuery + ",status,arrived";
				DailyReportController.ClacPatientsAmount(inputQuery);
				inputQuery="";

				dVal = DailyReportController.dailyRepEnt.GetPatientsAmount();
				System.out.println(dVal);
				lblPatientAmount.setText(Integer.toString(dVal));
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 15));
		DailyPanel.add(btnNewButton);
		
		JLabel lblPatients = new JLabel("Patients amount:");
		lblPatients.setBounds(24, 117, 133, 19);
		lblPatients.setFont(new Font("Tahoma", Font.PLAIN, 15));
		DailyPanel.add(lblPatients);
		
		lblPatientAmount = new JLabel("0");
		lblPatientAmount.setBounds(164, 117, 78, 19);
		lblPatientAmount.setFont(new Font("Tahoma", Font.PLAIN, 15));
		DailyPanel.add(lblPatientAmount);
		
		label_5 = new JLabel("Waiting time for appointment:");
		label_5.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_5.setBounds(21, 147, 221, 29);
		DailyPanel.add(label_5);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null},
			},
			new String[] {
				"0-30 days", "New column", "New column", "New column", "New column"
			}
		));
		table.setColumnSelectionAllowed(true);
		table.setCellSelectionEnabled(true);
		table.setForeground(Color.MAGENTA);
		table.setSurrendersFocusOnKeystroke(true);
		table.setBounds(419, 229, -209, -84);
		DailyPanel.add(table);
		
		lblDays = new JLabel("0-30 days");
		lblDays.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblDays.setForeground(Color.BLACK);
		lblDays.setBackground(Color.YELLOW);
		lblDays.setBounds(139, 200, 78, 19);
		DailyPanel.add(lblDays);
		
		lblDays_1 = new JLabel("31-60 days");
		lblDays_1.setForeground(Color.BLACK);
		lblDays_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblDays_1.setBackground(Color.YELLOW);
		lblDays_1.setBounds(227, 200, 78, 19);
		DailyPanel.add(lblDays_1);
		
		lblDays_2 = new JLabel("61-90 days");
		lblDays_2.setForeground(Color.BLACK);
		lblDays_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblDays_2.setBackground(Color.YELLOW);
		lblDays_2.setBounds(315, 200, 78, 19);
		DailyPanel.add(lblDays_2);
		
		lblDays_3 = new JLabel("91+");
		lblDays_3.setForeground(Color.BLACK);
		lblDays_3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblDays_3.setBackground(Color.YELLOW);
		lblDays_3.setBounds(410, 200, 40, 19);
		DailyPanel.add(lblDays_3);
		
		lblWaitingTime = new JLabel("Patients amount:");
		lblWaitingTime.setForeground(Color.BLACK);
		lblWaitingTime.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblWaitingTime.setBackground(Color.YELLOW);
		lblWaitingTime.setBounds(21, 230, 118, 19);
		DailyPanel.add(lblWaitingTime);
		
		lbl0 = new JLabel("0");
		lbl0.setHorizontalAlignment(SwingConstants.CENTER);
		lbl0.setForeground(Color.BLACK);
		lbl0.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lbl0.setBackground(Color.YELLOW);
		lbl0.setBounds(139, 230, 66, 19);
		DailyPanel.add(lbl0);
		
		lbl31 = new JLabel("0");
		lbl31.setHorizontalAlignment(SwingConstants.CENTER);
		lbl31.setForeground(Color.BLACK);
		lbl31.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lbl31.setBackground(Color.YELLOW);
		lbl31.setBounds(223, 230, 66, 19);
		DailyPanel.add(lbl31);
		
		lbl61 = new JLabel("0");
		lbl61.setHorizontalAlignment(SwingConstants.CENTER);
		lbl61.setForeground(Color.BLACK);
		lbl61.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lbl61.setBackground(Color.YELLOW);
		lbl61.setBounds(315, 230, 66, 19);
		DailyPanel.add(lbl61);
		
		lbl91p = new JLabel("0");
		lbl91p.setHorizontalAlignment(SwingConstants.CENTER);
		lbl91p.setForeground(Color.BLACK);
		lbl91p.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lbl91p.setBackground(Color.YELLOW);
		lbl91p.setBounds(402, 230, 46, 19);
		DailyPanel.add(lbl91p);
		
		lblNewLabel_2 = new JLabel("check input valid");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2.setForeground(Color.RED);
		lblNewLabel_2.setBounds(350, 72, 118, 19);
		DailyPanel.add(lblNewLabel_2);
		
		JButton btnDailyReport = new JButton("Daily Report");
		btnDailyReport.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnDailyReport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("Daily Report");
				DailyPanel.setVisible(true);

			}
		});
		btnDailyReport.setBounds(10, 233, 192, 39);
		contentPane.add(btnDailyReport);
	}
	
	
	//display the type of monthly report
	private void createEvents1() {
		btnViewMonthlyReport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				DailyPanel.setVisible(false);
				if (WeekRep != null )
					WeekRep.dispose();/// close week report if open
				if (Rep == null || Rep.isClosed())
				Rep = new TypeOfMonthlyReports();  ////  �� ����� ������ �� ������ ����� ������ 
				desktopReports.add(Rep);/// ���� �� ���� ����
				Rep.show(); // ������ �����
			}
		});
	}

	//for weekly report
	private void createEvents2() {
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DailyPanel.setVisible(false);
				if (Rep != null)
					Rep.dispose();/// close month report if open
				if (WeekRep == null || WeekRep.isClosed())
					WeekRep = new WeeklyReport();  ////  �� ����� ������ �� ������ ����� ������ 
					desktopReports.add(WeekRep);/// ���� �� ���� ����
					WeekRep.show(); // ������ �����
					
					//close whene pressed back
					WeekRep.backButton.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							WeekRep.dispose();
							 //
						}
					});	
			}
		});
		
	}
}
