package Entitys;



public class Weekly_Report_Entity {
	private int WeekNum;
	private float weekly_patient_amount_avg;
	private float weekly_patient_amount_max;
	private float weekly_patient_amount_min;
	private float weekly_patient_amount_deviation;// ����� ���
	private float weekly_waiting_time_avg;
	private float weekly_waiting_time_max;
	private float weekly_waiting_time_min;
	private float weekly_waiting_time_deviation;
	private int clinic_num;
	private boolean whole_partial; //���- 0         �����- 1

	public float getWeekNum() {
		return WeekNum;
	}
	
	public void setWeekNum(int val) {
		this.WeekNum= val ;
	}
	
	public int getClinic_num() {
		return clinic_num;
	}
	
	public void setClinic_num(int val) {
		this.clinic_num = val;
	}
	
	public boolean getWhole_partial() {
		return whole_partial;
	}
	
	public void setWhole_partial(boolean val) {
		whole_partial = val;
	}
	
	public float getAvgWaitingTimeForService() {
		return weekly_patient_amount_avg;
	}

	public void setAvgWaitingTimeForService(float val) {
		this.weekly_patient_amount_avg = val;
	}
	
	public float getMaxWaitingTimeForService() {
		return weekly_patient_amount_max;
	}

	public void setMaxWaitingTimeForService(float val) {
		this.weekly_patient_amount_max = val;
	}
	
	public float getMinWaitingTimeForService() {
		return weekly_patient_amount_min;
	}

	public void setMinWaitingTimeForService(float val) {
		this.weekly_patient_amount_min = val;
	}
	
	public float getStandardDiviationWaitingTimeForService() {
		return weekly_patient_amount_deviation;
	}

	public void setStandardDiviationWaitingTimeForService(float val) {
		this.weekly_patient_amount_deviation = val;
	}
	
	public float getAvgWaitingTimeForAppointment() {
		return weekly_waiting_time_avg;
	}
	
	public void setAVGWaitingTimeForAppointment(float val) {
		this.weekly_waiting_time_avg = val;
	}
	
	public float getMaxWaitingTimeForAppointment() {
		return  weekly_waiting_time_max;
	}

	public void setMaxWaitingTimeForAppointment(float val) {
		this.weekly_waiting_time_max = val;
	}
	
	public float getMinWaitingTimeForAppointment() {
		return weekly_waiting_time_min;
	}

	public void setMinWaitingTimeForAppointment(float val) {
		this.weekly_waiting_time_min = val;
	}
	
	public float getStandardDiviationWaitingTimeForAppointment() {
		return weekly_waiting_time_deviation;
	}	

	public void setStandardDiviationWaitingTimeForAppointment(float val) {
		this.weekly_waiting_time_deviation = val;
	}
}
