package controllers;

import java.util.ArrayList;

import javax.swing.JOptionPane;

import Entitys.Daily_Report_Entity;

public class DailyReportController {
	public static Daily_Report_Entity dailyRepEnt = new Daily_Report_Entity();
	
	public static void InsetDailyDetails(String inputQuery){
	
	}
	
	public static void ClacPatientsAmount(String inputQuery){
		ArrayList <String> data = new ArrayList<String>();
		
		data=jdbc.mysqlConnection.ActionMode(inputQuery.toString());
		if(data.isEmpty())
			JOptionPane.showMessageDialog(null,"Please insert a date.", "Date Error", JOptionPane.ERROR_MESSAGE);
		else
			dailyRepEnt.SetPatientsAmount(data.size());
	}
	
	public static void Clac0_30Patients(String inputQuery){
		
	}
}
