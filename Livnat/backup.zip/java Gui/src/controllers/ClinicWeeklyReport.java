package controllers;

import java.util.ArrayList;

import javax.swing.JOptionPane;

import Entitys.Weekly_Report_Entity;

public class ClinicWeeklyReport {
	public static Weekly_Report_Entity week_rep = new Weekly_Report_Entity();

	// inputQuery = 
	public static void ShowByDate(String inputQuery){
		ArrayList <String> data = new ArrayList<String>();
		String [] dataDB;
		
		data=jdbc.mysqlConnection.ActionMode(inputQuery.toString());
		if(data.isEmpty())
			JOptionPane.showMessageDialog(null,"Please insert a date.", "Date Error", JOptionPane.ERROR_MESSAGE);
		else
		{
			dataDB=data.get(0).split(",");
			System.out.println("start it");
			for(String item: dataDB)
				System.out.println(item);
			System.out.println("end it");
			week_rep.setAVGWaitingTimeForAppointment(Float.parseFloat(dataDB[2]));
		}
	}
}
