package Entitys;

public class Monthly_Report_Entity {
	private String month_date;
	private int clinic_num;
	private int monthly_patient_amount;
	private float monthly_patients_amount_avg;
	private int monthly_patients_amount_max;
	private int monthly_patients_amount_min;
	private float monthly_patients_amount_deviation;
	private int left_patients_amount;
	private int not_reached_amount;
	private int waiting_month_0;
	private int waiting_month_1;
	private int waiting_month_2;
	private int waiting_month_3;
	
	
	// Get
	public int getMonthlyPatientAmount() { 
		return this.monthly_patient_amount;
	}
	
	public float getMonthlyWaitingTimeAVG() {
		return this.monthly_patients_amount_avg;
	}
	
	public int getMonthlyWaitingTimeMin() {
		return this.monthly_patients_amount_min;
	}
	
	public int getMonthlyWaitingTimeMax() {
		return this.monthly_patients_amount_max;
	}
	
	public float getMonthlyWaitingTimeDevision() {
		return this.monthly_patients_amount_deviation;
	}
	
	public int getLeftPatientsAmount() {
		return this.left_patients_amount;
	}
	
	public int getNotReachedPatientAmount() {
		return this.not_reached_amount;
	}
	
	public int getWaiting_Month_0() {
		return this.waiting_month_0;
	}
	public int getWaiting_Month_1() {
		return this.waiting_month_1;
	}
	public int getWaiting_Month_2() {
		return this.waiting_month_2;
	}
	public int getWaiting_Month_3() {
		return this.waiting_month_3;
	}
	
	
	// Set
	public void setMonthlyPatientAmount(int val) {
		monthly_patient_amount = val;
	}
	
	public void setMonthlyWaitingTimeAVG(float val) {
		monthly_patients_amount_avg = val;
	}
	
	public void setMonthlyWaitingTimeMin(int val) {
		monthly_patients_amount_min  = val;;
	}
	
	public void setMonthlyWaitingTimeMax(int val) {
		monthly_patients_amount_max  = val;;
	}
	
	public void setMonthlyWaitingTimeDevision(float val) {
		monthly_patients_amount_deviation  = val;
	}
	
	public void SetLeftPatientsAmount(int val) {
		left_patients_amount = val;
	}
	
	public void SetNotReachedPatientAmount(int val) {
		not_reached_amount = val;
	}
	
	public void setWaiting_Month_0(int val) {
		waiting_month_0 = val;
	}
	public void setWaiting_Month_1(int val) {
		waiting_month_1 = val;
	}
	public void setWaiting_Month_2(int val) {
		waiting_month_2 = val;
	}
	public void setWaiting_Month_3(int val) {
		waiting_month_3 = val;
	}
}
