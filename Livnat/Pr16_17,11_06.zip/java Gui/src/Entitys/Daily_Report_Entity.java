package Entitys;

public class Daily_Report_Entity {
	private int clinic_num;
	private String date;	
	private int day_num;
	private int patients_amount;
	private float waiting_time_avg;
	private int waiting_time_max;	// days amount
	private int waiting_time_min;
	private int waiting_time_deviation;
	private int waiting_month_0;
	private int waiting_month_1;
	private int waiting_month_2;
	private int waiting_month_3;
	private String start_week_date;
	private int daily_min_waiting;	// to calc
	private int daily_max_waiting;	// to calc
	
	/* ���� �� �����, ������� �� ������ ������ ����� �� ��� ����, �����.
	 * ���� �� ���� ���� ������ ������ �� ������.
	 * ����� ��� ���� ����� ��� ����� ���, ����� ����� ���� ����� ���.
	 */
	
	public Daily_Report_Entity(){
		InitAll();
	}
	

	public void InitAll(){
		patients_amount = 0;
		waiting_time_avg = 0;
		waiting_time_max = 0;
		waiting_time_min = 0;
		waiting_time_deviation = 0;
		waiting_month_0 = 0;
		waiting_month_1 = 0;
		waiting_month_2 = 0;
		waiting_month_3 = 0;
		daily_min_waiting = 0;
		daily_max_waiting = 0;
	}
	
	// Get
	public int GetClinicNum(){
		return this.clinic_num;
	}
	
	public String GetDate(){
		return this.date;
	}
	
	public int GetDayNum(){
		return this.day_num;
	}

	public int GetPatientsAmount(){
		return this.patients_amount;
	}

	public float GetWaitingTimeAvg(){
		return this.waiting_time_avg;
	}

	public int GetWaitingTimeMax(){
		return this.waiting_time_max;
	}

	public int GetWaitingTimeMin(){
		return this.waiting_time_min;
	}
	
	public int GetWwaitingTimeDeviation(){
		return this.waiting_time_deviation;
	}
	
	public int GetWaiting_month_0(){
		return this.waiting_month_0;
	}

	public int GetWaiting_month_1(){
		return this.waiting_month_1;
	}

	public int GetWaiting_month_2(){
		return this.waiting_month_2;
	}
	
	public int GetWaiting_month_3(){
		return this.waiting_month_3;
	}

	public String GetStart_week_date(){
		return this.start_week_date;
	}

	
	
	// Set	
	public void SetClinicNum(int val){
		this.clinic_num = val;
	}

	public void SetDate(String date){
		this.date = date;
	}
	
	public boolean SetDayNum(int dayIndex){
		if(dayIndex < 1 || dayIndex > 7)
			return false;
		this.day_num = dayIndex;
		return true;
	}

	public void SetPatientsAmount(int val){
		if(val > 0)
			this.patients_amount = val;
	}

	public void SetWaitingTimeAvg(float val){
		if(val > 0)
			this.waiting_time_avg = val;
	}

	public void SetWaitingTimeMax(int val){
		this.waiting_time_max = val;
	}

	public void SetWaitingTimeMin(int val){
		this.waiting_time_min = val;
	}
	
	public void SetWwaitingTimeDeviation(int val){
		this.waiting_time_deviation = val;
	}
	
	public void SetWaiting_month_0(int val){
		this.waiting_month_0 = val;
	}

	public void SetWaiting_month_1(int val){
		this.waiting_month_1 = val;
	}

	public void SetWaiting_month_2(int val){
		this.waiting_month_2 = val;
	}

	public void SetWaiting_month_3(int val){
		this.waiting_month_3 = val;
	}
	
	public void SetStart_week_date(String date){
		this.start_week_date = date;
	}
	
	
	public void SetDailyMinWaiting(int days){
		this.daily_min_waiting = days;
	}
	
	public void SetDailyMaxWaiting(int days){
		this.daily_max_waiting = days;
	}
	
	
	//Inc
	public void IncWaiting_month_0(){
		this.waiting_month_0++;
	}

	public void IncWaiting_month_1(){
		this.waiting_month_1++;
	}

	public void IncWaiting_month_2(){
		this.waiting_month_2++;
	}

	public void IncWaiting_month_3(){
		this.waiting_month_3++;
	}
}
