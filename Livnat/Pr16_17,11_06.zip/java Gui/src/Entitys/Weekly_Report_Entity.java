package Entitys;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;


public class Weekly_Report_Entity {
	private String start_week_date;
	private int clinic_num;
	private int Week_num;	// to calc
	private int patients_amount;
	private float Weekly_waiting_time_avg;
	private int Weekly_waiting_time_max;	// to calc
	private int Weekly_waiting_time_min;	// to calc
	private float Weekly_waiting_time_deviation;	// to calc
	private boolean Whole_Partial; //whole- 0  partial- 1	// to calc
	private int waiting_month_0;
	private int waiting_month_1;
	private int waiting_month_2;
	private int waiting_month_3;
	private String month_date;
	private ArrayList<String> existDates;
	
//	private ArrayList<Integer> arr_clinicNumber;
//	private ArrayList<String> arr_clinicName;
    private Daily_Report_Entity[] dailyArr = new Daily_Report_Entity[7];
    private int countDays = 0;
    
    public Weekly_Report_Entity(){
    	InitAll();
    	existDates = new ArrayList<String>();
    	
    	for(int i=0; i<7; i++)
    		dailyArr[i] = new Daily_Report_Entity();
    	
//		this.arr_clinicNumber = new ArrayList<Integer>();
//		this.arr_clinicName = new ArrayList<String>();
    }
    
    public void InitAll(){
    	this.Week_num = 1;
    	this.patients_amount = 0;
    	this.Weekly_waiting_time_avg = 0;
    	this.Weekly_waiting_time_max = 0;
    	this.Weekly_waiting_time_min = 0;
    	this.Weekly_waiting_time_deviation = 0;
    	this.Whole_Partial = true;
    	this.waiting_month_0 = 0;
    	this.waiting_month_1 = 0;
    	this.waiting_month_2 = 0;
    	this.waiting_month_3 = 0;
    }
    
    
    public void CreateWeeklyReport(){
    	CalcWeeklyPatientsAmount();
    	CalcWaitingMonths_0_3();
    	CalcWeeklyWaitingTimeAvg();
    	CalcWeeklyMinMax(); 		// ??????
    	CalcWeeklyWaitingTimeDeviation();		// ?????
    }
    
    public void CalcWeeklyPatientsAmount(){
    	int i, patientAmountSum = 0;
    	for(i=0; i< 7; i++)
    		patientAmountSum += dailyArr[i].GetPatientsAmount();
    	this.patients_amount = patientAmountSum;
    }
    
    public void CalcWaitingMonths_0_3(){
    	int i, sum0=0, sum1=0, sum2=0, sum3=0;
    	for(i=0; i< 7; i++)
    	{
    		sum0 += dailyArr[i].GetWaiting_month_0();
    		sum1 += dailyArr[i].GetWaiting_month_1();
    		sum2 += dailyArr[i].GetWaiting_month_2();
    		sum3 += dailyArr[i].GetWaiting_month_3();
    	}
    	this.waiting_month_0 = sum0;
    	this.waiting_month_0 = sum1;
    	this.waiting_month_0 = sum2;
    	this.waiting_month_0 = sum3;
    }
    
    public void CalcWeeklyWaitingTimeAvg(){
    	int sum;
    	
    	sum = getWaitingMonth_0() + getWaitingMonth_1() + getWaitingMonth_2() + getWaitingMonth_3();
    	this.Weekly_waiting_time_avg = (float)sum/patients_amount;
    }
    
    public void CalcWeeklyMinMax(){		// ?????
		// ?????
    }


    public void CalcWeeklyWaitingTimeDeviation(){		// ?????
    	float dev = 0;
		// ?????
    	
    	Weekly_waiting_time_deviation = dev;
    }
    
    
    public int SaveDayInWeekReport(Daily_Report_Entity dailyReport, int dayNum){
    	if(dayNum < 1 || dayNum > 7)
    		return -1;	// Error
    	
    	
    	dailyArr[dayNum-1].SetDate(dailyReport.GetDate());
    	dailyArr[dayNum-1].SetClinicNum(dailyReport.GetClinicNum());
    	dailyArr[dayNum-1].SetDayNum(dailyReport.GetDayNum());
    	dailyArr[dayNum-1].SetPatientsAmount(dailyReport.GetPatientsAmount());
    	dailyArr[dayNum-1].SetWaitingTimeAvg(dailyReport.GetWaitingTimeAvg());
    	dailyArr[dayNum-1].SetWaitingTimeMax(dailyReport.GetWaitingTimeMax());
    	dailyArr[dayNum-1].SetWaitingTimeMin(dailyReport.GetWaitingTimeMin());
    	dailyArr[dayNum-1].SetWwaitingTimeDeviation(dailyReport.GetWwaitingTimeDeviation());
    	dailyArr[dayNum-1].SetWaiting_month_0(dailyReport.GetWaiting_month_0());
    	dailyArr[dayNum-1].SetWaiting_month_1(dailyReport.GetWaiting_month_1());
    	dailyArr[dayNum-1].SetWaiting_month_2(dailyReport.GetWaiting_month_2());
    	dailyArr[dayNum-1].SetWaiting_month_3(dailyReport.GetWaiting_month_3());
    	dailyArr[dayNum-1].SetStart_week_date(dailyReport.GetStart_week_date());
    	
    	countDays++;
    	
    	if(dayNum == 7 || countDays == 8)	// good???
    	{
    		countDays = 0;
    		return 0;	// new begging, insert weekly report to db.
    	}
    	
    	return 1; // true
    }
    
    
    public Daily_Report_Entity GetDayInWeekReport(int dayNum){
    	return dailyArr[dayNum-1];
    }

    
    
    
    
    
    
    
    
    // ==========================
    
    /*
	public int getClinicsAmount(){
		return arr_clinicNumber.size();
	}
	
	
	public String getClinicName(int index){
		return arr_clinicName.get(index);
	//	return hm_clinics.get(index);
	}
	
	public int getClinicNum(int index){
		return arr_clinicNumber.get(index);
	}
	
	public String getClinicNameByKey(int clinicNum){
		for(int i=0; i<arr_clinicNumber.size(); i++)
			if(arr_clinicNumber.get(i) == clinicNum)
				return arr_clinicName.get(i);
		return null;
	}
	*/
/*	public void printAll(){
	     Iterator iterator = hm_clinics.entrySet().iterator();
	      while(iterator.hasNext()) {
	         Map.Entry mentry = (Map.Entry)iterator.next();
	         System.out.print("key is: "+ mentry.getKey() + " & Value is: ");
	         System.out.println(mentry.getValue());
	      }
	}
*/	
	/*
	public void saveClinicDetails(ArrayList <String> data){
		String[] strSplit;
		
		for(int i=0; i<data.size(); i++)	// for each line in table
		{
			strSplit = data.get(i).split(",");
			arr_clinicNumber.add(Integer.parseInt(strSplit[1]));
			arr_clinicName.add(strSplit[2]);
			System.out.println("clinic " + arr_clinicNumber.get(i)+": " + arr_clinicName.get(i));
		}
	}
	*/
	
	
	
	// Get
	public String getStartWeekDate(){
		return this.start_week_date;
	}
	
	public int getClinicNum(){
		return this.clinic_num;
	}
	
	public int getWeekNum(){
		return this.Week_num;
	}
	
	public int getPatientsAmount(){
		return this.patients_amount;
	}
	
	public float getWeeklyWaitingTimeAvg(){
		return this.Weekly_waiting_time_avg;
	}
	
	public int getWeeklyWaitingTimeMax(){
		return this.Weekly_waiting_time_max;
	}
	
	public int getWeeklyWaitingTimeMin(){
		return this.Weekly_waiting_time_min;
	}
	
	public float getWeeklyWaitingTimeDeviation(){
		return this.Weekly_waiting_time_deviation;
	}
	
	public boolean getWhole_Partial(){
		return this.Whole_Partial;
	}
	
	public int getWaitingMonth_0(){
		return this.waiting_month_0;
	}
	
	public int getWaitingMonth_1(){
		return this.waiting_month_1;
	}
	
	public int getWaitingMonth_2(){
		return this.waiting_month_2;
	}
	
	public int getWaitingMonth_3(){
		return this.waiting_month_3;
	}
	
	public String getMonthDate(){
		return this.month_date;
	}
	
	public String getExistDateByIndex (int index){
		return this.existDates.get(index);
	}
	
	public ArrayList<String> getExistDates (){
		return this.existDates;
	}
	
	public int getDatesAmount(){
		return existDates.size();
	}
	
	
	// Set
	public void setStartWeekDate(String date){
		this.start_week_date = date;
	}
	
	public void setClinicNum(int val){
		this.clinic_num = val;
	}
	
	public void setWeekNum(int val){
		this.Week_num = val;
	}

	public void setPatientsAmount(int val){
		this.patients_amount = val;
	}
	
	public void setWeeklyWaitingTimeAvg(float val){
		this.Weekly_waiting_time_avg = val;
	}
	
	public void setWeeklyWaitingTimeMax(int val){
		this.Weekly_waiting_time_max = val;
	}
	
	public void setWeeklyWaitingTimeMin(int val){
		this.Weekly_waiting_time_min = val;
	}
	
	public void setWeeklyWaitingTimeDeviation(float val){
		this.Weekly_waiting_time_deviation = val;
	}

	public void setWhole_Partial(boolean val){
		this.Whole_Partial = val;
	}
	
	public void setWaitingMonth_0(int val){
		 this.waiting_month_0 = val;
	}
	
	public void setWaitingMonth_1(int val){
		this.waiting_month_1 = val;
	}
	
	public void setWaitingMonth_2(int val){
		this.waiting_month_2 = val;
	}
	
	public void setWaitingMonth_3(int val){
		this.waiting_month_3 = val;
	}

	public void setMonthDate(String date){
		this.month_date = date;
	}

	public void insertExistDate (String date){
		this.existDates.add(date);
	}
	
	public void setExistDates(ArrayList <String> data){
		for(String item: data)
			this.existDates.add(item);
	}
}
