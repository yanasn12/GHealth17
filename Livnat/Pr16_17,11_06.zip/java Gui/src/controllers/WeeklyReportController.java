package controllers;

import java.util.ArrayList;

import javax.swing.JOptionPane;

import Entitys.Daily_Report_Entity;
import Entitys.Weekly_Report_Entity;

public class WeeklyReportController {
	public static Weekly_Report_Entity week_rep = new Weekly_Report_Entity();
	
	public static void pullWeeklyDates(String inputQuery){
		ArrayList <String> data = new ArrayList<String>();
		ArrayList <String> temp = new ArrayList<String>();
		String [] dataDB;
		
		data=jdbc.mysqlConnection.ActionMode(inputQuery.toString());
		for(int i=0; i<data.size(); i++)
		{
			dataDB = data.get(i).split(",");
			week_rep.insertExistDate(dataDB[1]);
		}
		temp = week_rep.getExistDates();
		for(int i=0; i<temp.size(); i++)
			System.out.println("temp.get("+i+"): "+temp.get(i));
		
		//week_rep.setExistDates(data);
	//	week_rep.set
		System.out.println();
	}
	
	
	
	
	
	public static void InsertDailyReport(Daily_Report_Entity dailyRepEnt, int dayIndex){
		int res = week_rep.SaveDayInWeekReport(dailyRepEnt, dayIndex);
		System.out.println("week_rep.SaveDayInWeekReport RES: "+res);
		if(res == -1)
			JOptionPane.showMessageDialog(null,"That day of week doesn't exist.", "Date Error", JOptionPane.ERROR_MESSAGE);
		else if(res == 1)
			JOptionPane.showMessageDialog(null,"The dayly report saved successfuly.", "Insert successful", JOptionPane.PLAIN_MESSAGE);
		else // res == 0: start a new week.
		{
			MakeWeeklyReport();
			// update weekly_report dbTable by date key, calculate and save all details.
			// Insert new key
		}
		System.out.println("Insert rep to db");
	} // end InsertDailyReport
	
	
	public static void MakeWeeklyReport(){
		week_rep.CreateWeeklyReport();
	}
	
	
	public static void InsertWeeklyDetailsToDB(String inputQuery){
		jdbc.mysqlConnection.ActionMode(inputQuery.toString());
	}
	
	// ===============================================
	/*		// ���� - ����� ������ ��� ������ �����, ������ �� ����.
	 * inputQuery="pullbykey:weekly_report:"+ "start_week_date," + date;
	*/
	public static void ShowByDate(String inputQuery){
		ArrayList <String> data = new ArrayList<String>();
		String [] dataDB;
		
		data=jdbc.mysqlConnection.ActionMode(inputQuery.toString());
		if(data.isEmpty())
			JOptionPane.showMessageDialog(null,"No reports for that date.", "Date Error", JOptionPane.ERROR_MESSAGE);
		else
		{
			dataDB=data.get(0).split(",");
			
			// Update entity details
			week_rep.setStartWeekDate(dataDB[1]);
			week_rep.setClinicNum(Integer.parseInt(dataDB[2]));
			week_rep.setWeekNum(Integer.parseInt(dataDB[3]));
			week_rep.setPatientsAmount(Integer.parseInt(dataDB[4]));
			week_rep.setWeeklyWaitingTimeAvg(Float.parseFloat(dataDB[5]));
			week_rep.setWeeklyWaitingTimeMax(Integer.parseInt(dataDB[6]));
			week_rep.setWeeklyWaitingTimeMin(Integer.parseInt(dataDB[7])); // Weekly_waiting_time_min
			week_rep.setWeeklyWaitingTimeDeviation(Float.parseFloat(dataDB[8])); // Weekly_waiting_time_deviation
			
		//	week_rep.setWhole_Partial(dataDB[9]); // Whole_Partial
			week_rep.setWaitingMonth_0(Integer.parseInt(dataDB[10])); // waiting_month_0
			week_rep.setWaitingMonth_1(Integer.parseInt(dataDB[11])); // waiting_month_1
			week_rep.setWaitingMonth_2(Integer.parseInt(dataDB[12])); // waiting_month_2
			week_rep.setWaitingMonth_3(Integer.parseInt(dataDB[13])); // waiting_month_3
			week_rep.setMonthDate(dataDB[14]); // month_date
			
			System.out.println("pass");
			if(dataDB[8] == "true")
				week_rep.setWhole_Partial(true);
			else
				week_rep.setWhole_Partial(false);
				
			
		//	week_rep.setWeeklyWaitingTimeAvg(Float.parseFloat(dataDB[2]));
		}
	}
	
	/*
	public static void ClinicDetails(String inputQuery){
		ArrayList <String> data = new ArrayList<String>();
		data=jdbc.mysqlConnection.ActionMode(inputQuery.toString());
		System.out.println("333 Before entity setting");
		week_rep.saveClinicDetails(data);
		System.out.println("333 After entity setting");
	}
	*/
}
