package controllers;

import java.util.ArrayList;

import javax.swing.JOptionPane;

import Entitys.Monthly_Report_Entity;

public class MonthlyReportController {
	public static Monthly_Report_Entity MonthlyRepEnt = new Monthly_Report_Entity();
	
	public static void CalcMonthlyDetails(String inputQuery){
		ArrayList <String> data = new ArrayList<String>();
		int i, sum0=0, sum1=0, sum2=0, sum3=0, sum=0;
		int patientsAmount;
		float fVal;
		String[] details;
		
		data=jdbc.mysqlConnection.ActionMode(inputQuery.toString());
		if(data.isEmpty())
			JOptionPane.showMessageDialog(null,"Please insert a date.", "Date Error", JOptionPane.ERROR_MESSAGE);
		else
		{
			patientsAmount = data.size();
			MonthlyRepEnt.setMonthlyPatientAmount(patientsAmount);
			
			// CalcWaitingMonths_0_3
			for (String item : data)
			{
				details=item.split(",");
				sum0 += Integer.parseInt(details[9]);
	    		sum1 += Integer.parseInt(details[10]);
	    		sum2 += Integer.parseInt(details[11]);
	    		sum3 += Integer.parseInt(details[12]);
	    		sum += sum0 + sum1 + sum2 + sum3;
			}
	    	MonthlyRepEnt.setWaiting_Month_0(sum0);
	    	MonthlyRepEnt.setWaiting_Month_1(sum1);
	    	MonthlyRepEnt.setWaiting_Month_2(sum2);
	    	MonthlyRepEnt.setWaiting_Month_3(sum3);
	    	// Calc avg
	    	fVal = (float)sum/patientsAmount;
	    	MonthlyRepEnt.setMonthlyWaitingTimeAVG(fVal);
	    	
	    	MonthlyRepEnt.setMonthlyWaitingTimeMax(0); // CALC
	    	MonthlyRepEnt.setMonthlyWaitingTimeMin(0); // CALC
	    	MonthlyRepEnt.setMonthlyWaitingTimeDevision(0); // CALC
		}// end else
	} // end CalcMonthlyDetails
	
	public static void CalcLeavePatients(String inputQuery){
		ArrayList <String> data = new ArrayList<String>();
		data=jdbc.mysqlConnection.ActionMode(inputQuery.toString());
		
		if(data.isEmpty())
			JOptionPane.showMessageDialog(null,"Please insert a date.", "Date Error", JOptionPane.ERROR_MESSAGE);
		else
			MonthlyRepEnt.setMonthlyPatientAmount(data.size());
	} // end CalcLeavePatients
	
	
}
