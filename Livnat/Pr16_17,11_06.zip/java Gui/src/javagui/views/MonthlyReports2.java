package javagui.views;
import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import javax.swing.UIManager;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;


public class MonthlyReports2 extends JInternalFrame {
	private JTextField textField;
	public JButton button;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MonthlyReports frame = new MonthlyReports();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MonthlyReports2() {
		setBounds(0, 0, 497, 501);
		getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 11, 457, 449);
		panel.setLayout(null);
		panel.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Monthly Report", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		getContentPane().add(panel);
		
		JLabel label = new JLabel("Date : ");
		label.setBounds(10, 29, 46, 14);
		panel.add(label);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(51, 26, 86, 20);
		panel.add(textField);
		
		JLabel lblMonthlyReport = new JLabel("Monthly Report");
		lblMonthlyReport.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblMonthlyReport.setBounds(134, 57, 168, 33);
		panel.add(lblMonthlyReport);
		
		JLabel lblLeftPatientsAmount = new JLabel("Left patients amount:");
		lblLeftPatientsAmount.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblLeftPatientsAmount.setBounds(10, 347, 194, 14);
		panel.add(lblLeftPatientsAmount);
		
		JLabel lblNotReachedPatient = new JLabel("Not reached patient amount");
		lblNotReachedPatient.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNotReachedPatient.setBounds(10, 375, 212, 14);
		panel.add(lblNotReachedPatient);
		
		button = new JButton("Back");
	
		button.setIcon(new ImageIcon(MonthlyReports.class.getResource("/javagui/resources/Back.png")));
		button.setBounds(324, 397, 108, 41);
		panel.add(button);
		
		JLabel label_2 = new JLabel("Patients amount:");
		label_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_2.setBounds(10, 101, 127, 14);
		panel.add(label_2);
		
		JLabel label_3 = new JLabel("0");
		label_3.setHorizontalAlignment(SwingConstants.CENTER);
		label_3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_3.setBounds(223, 103, 46, 14);
		panel.add(label_3);
		
		JLabel label_4 = new JLabel("Waiting time for appointment:");
		label_4.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_4.setBounds(10, 129, 194, 14);
		panel.add(label_4);
		
		JLabel label_7 = new JLabel("- Average value:");
		label_7.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_7.setBounds(77, 154, 145, 20);
		panel.add(label_7);
		
		JLabel label_8 = new JLabel("- Minimum value:");
		label_8.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_8.setBounds(77, 173, 145, 23);
		panel.add(label_8);
		
		JLabel label_9 = new JLabel("- Maximum value:");
		label_9.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_9.setBounds(77, 194, 145, 23);
		panel.add(label_9);
		
		JLabel label_10 = new JLabel("- Standard deviation:");
		label_10.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_10.setBounds(78, 215, 144, 20);
		panel.add(label_10);
		
		JLabel label_11 = new JLabel("0");
		label_11.setHorizontalAlignment(SwingConstants.CENTER);
		label_11.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_11.setBounds(223, 220, 46, 14);
		panel.add(label_11);
		
		JLabel label_12 = new JLabel("0");
		label_12.setHorizontalAlignment(SwingConstants.CENTER);
		label_12.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_12.setBounds(223, 200, 46, 14);
		panel.add(label_12);
		
		JLabel label_13 = new JLabel("0");
		label_13.setHorizontalAlignment(SwingConstants.CENTER);
		label_13.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_13.setBounds(223, 179, 46, 14);
		panel.add(label_13);
		
		JLabel label_14 = new JLabel("0");
		label_14.setHorizontalAlignment(SwingConstants.CENTER);
		label_14.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_14.setBounds(223, 159, 46, 14);
		panel.add(label_14);
		
		JLabel label_39 = new JLabel("Month:");
		label_39.setForeground(Color.BLACK);
		label_39.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_39.setBackground(Color.YELLOW);
		label_39.setBounds(77, 271, 60, 19);
		panel.add(label_39);
		
		JLabel lblPatientsAmount = new JLabel(" Patients amount:");
		lblPatientsAmount.setForeground(Color.BLACK);
		lblPatientsAmount.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblPatientsAmount.setBackground(Color.YELLOW);
		lblPatientsAmount.setBounds(10, 301, 118, 19);
		panel.add(lblPatientsAmount);
		
		JLabel label_41 = new JLabel("0");
		label_41.setHorizontalAlignment(SwingConstants.CENTER);
		label_41.setForeground(Color.BLACK);
		label_41.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_41.setBackground(Color.YELLOW);
		label_41.setBounds(128, 301, 66, 19);
		panel.add(label_41);
		
		JLabel label_42 = new JLabel("0 - 1");
		label_42.setHorizontalAlignment(SwingConstants.CENTER);
		label_42.setForeground(Color.BLACK);
		label_42.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_42.setBackground(Color.YELLOW);
		label_42.setBounds(134, 271, 60, 19);
		panel.add(label_42);
		
		JLabel label_43 = new JLabel("1 - 2");
		label_43.setHorizontalAlignment(SwingConstants.CENTER);
		label_43.setForeground(Color.BLACK);
		label_43.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_43.setBackground(Color.YELLOW);
		label_43.setBounds(204, 271, 60, 19);
		panel.add(label_43);
		
		JLabel label_44 = new JLabel("0");
		label_44.setHorizontalAlignment(SwingConstants.CENTER);
		label_44.setForeground(Color.BLACK);
		label_44.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_44.setBackground(Color.YELLOW);
		label_44.setBounds(204, 301, 66, 19);
		panel.add(label_44);
		
		JLabel label_45 = new JLabel("0");
		label_45.setHorizontalAlignment(SwingConstants.CENTER);
		label_45.setForeground(Color.BLACK);
		label_45.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_45.setBackground(Color.YELLOW);
		label_45.setBounds(268, 301, 66, 19);
		panel.add(label_45);
		
		JLabel label_46 = new JLabel("2 - 3");
		label_46.setHorizontalAlignment(SwingConstants.CENTER);
		label_46.setForeground(Color.BLACK);
		label_46.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_46.setBackground(Color.YELLOW);
		label_46.setBounds(274, 271, 60, 19);
		panel.add(label_46);
		
		JLabel label_47 = new JLabel("3 + ");
		label_47.setHorizontalAlignment(SwingConstants.CENTER);
		label_47.setForeground(Color.BLACK);
		label_47.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_47.setBackground(Color.YELLOW);
		label_47.setBounds(344, 271, 52, 19);
		panel.add(label_47);
		
		JLabel label_48 = new JLabel("0");
		label_48.setHorizontalAlignment(SwingConstants.CENTER);
		label_48.setForeground(Color.BLACK);
		label_48.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_48.setBackground(Color.YELLOW);
		label_48.setBounds(344, 301, 52, 19);
		panel.add(label_48);
		
		JLabel label_5 = new JLabel("0");
		label_5.setHorizontalAlignment(SwingConstants.CENTER);
		label_5.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_5.setBounds(224, 347, 46, 14);
		panel.add(label_5);
		
		JLabel label_6 = new JLabel("0");
		label_6.setHorizontalAlignment(SwingConstants.CENTER);
		label_6.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_6.setBounds(223, 377, 46, 14);
		panel.add(label_6);

	}
}
