package javagui.views;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Color;

import javax.swing.ImageIcon;

import java.awt.Toolkit;

import javax.swing.JButton;

import java.awt.Font;

import javax.swing.SwingConstants;
import javax.swing.JDesktopPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;

import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import javax.swing.JTextField;

import Entitys.Daily_Report_Entity;
import controllers.MonthlyReportController;
import controllers.WeeklyReportController;
import controllers.DailyReportController;

import javax.swing.border.TitledBorder;
import javax.swing.UIManager;
import javax.swing.JToggleButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class CliniclManegementReport extends JFrame {
	
	private JPanel contentPane;
	private JDesktopPane desktopReports;
	private JButton btnViewMonthlyReport;
	private TypeOfMonthlyReports Rep;
	public WeeklyReport WeekRep;
	private JButton btnViewWeeklyReport;
	private JTextField dateField;
	private JPanel DailyPanel, WeeklyPanel, MonthlyPanel;
	private JPanel WeeklyPanel_1;
	private JLabel lblPatientAmount;
	private String inputQuery;
	private JLabel label_5;
	private JTable table;
	private JLabel lblDays_2;
	private JLabel lblDays_3;
	private JLabel lblWaitingTime;
	private JLabel lbl0;
	private JLabel lbl1;
	private JLabel lbl2;
	private JLabel lbl3;
	private JLabel lblMonth;
	private JTextField clinicField;
	private JLabel label_2;
	private JLabel label_3;
	private JLabel label_4;
	private JButton button_2;
	private JLabel label_6;
	private JLabel label_7;
	private JLabel label_8;
	private JLabel label_9;
	private JLabel label_10;
	private JLabel label_11;
	private JLabel lblm0;
	private JLabel label_13;
	private JLabel lblm1;
	private JLabel label_15;
	private JLabel lblm2;
	private JLabel label_17;
	private JLabel lblm3;
	private JLabel label_19;
	private JLabel lblpAmount;
	private JLabel lblAvg;
	private JLabel lblMin;
	private JLabel lblMax;
	private JLabel lblDev;
	private JLabel lblChooseDate;
	private JComboBox<String> cbWeeklyDate;
	private JLabel label_28;
	private JTextField textField;
	private JLabel label_29;
	private JLabel label_30;
	private JLabel label_31;
	private JButton button;
	private JLabel label_32;
	private JLabel label_33;
	private JLabel label_34;
	private JLabel label_35;
	private JLabel label_36;
	private JLabel label_37;
	private JLabel label_38;
	private JLabel label_39;
	private JLabel label_40;
	private JLabel label_41;
	private JLabel label_42;
	private JLabel label_43;
	private JLabel label_44;
	private JLabel label_45;
	private JLabel label_46;
	private JLabel label_47;
	private JLabel label_48;
	private JLabel label_49;
	private JLabel label_50;
	private JLabel label_51;
	private JLabel label_52;
	private JLabel label_53;
	private JLabel label_54;
	private JButton btnCreateDailyReport;
	private JTextField MainTxtClinicNum;
	private JButton btnCreateMonthlyreport;
	private JTextField MainTxtClinicName;
	
	private int DayCounter = 1;	// DELL

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CliniclManegementReport frame = new CliniclManegementReport();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public CliniclManegementReport() {
		initComponent(); //// ����� �� INIT ��� �� �� �� ������ ��������
		createEvents1();/// ����� ������- ���� ����
		DisplayMontlyDate();
		//createEvents3();
	}
	
	///////// init component of desktop reports
	private void initComponent() {
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(CliniclManegementReport.class.getResource("/javagui/resources/GHealthlogo.png")));
		label.setBounds(113, 25, 242, 68);
		contentPane.add(label);
		
		btnViewWeeklyReport = new JButton("View weekly reports");
		btnViewWeeklyReport.setIcon(new ImageIcon(CliniclManegementReport.class.getResource("/javagui/resources/img16x16/reports.png")));
		btnViewWeeklyReport.setHorizontalAlignment(SwingConstants.LEFT);
		btnViewWeeklyReport.setForeground(Color.BLUE);
		btnViewWeeklyReport.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnViewWeeklyReport.setBackground(Color.WHITE);
		btnViewWeeklyReport.setBounds(10, 133, 192, 39);
		btnViewWeeklyReport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CreateWeeklyReport();
			}
		});
		contentPane.add(btnViewWeeklyReport);
		
		btnViewMonthlyReport = new JButton("View monthly report ");
		
		btnViewMonthlyReport.setIcon(new ImageIcon(CliniclManegementReport.class.getResource("/javagui/resources/img16x16/reports.png")));
		btnViewMonthlyReport.setHorizontalAlignment(SwingConstants.LEFT);
		btnViewMonthlyReport.setForeground(Color.BLUE);
		btnViewMonthlyReport.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnViewMonthlyReport.setBackground(Color.WHITE);
		btnViewMonthlyReport.setBounds(10, 183, 192, 39);
		contentPane.add(btnViewMonthlyReport);
		
		desktopReports = new JDesktopPane();
		desktopReports.setBackground(Color.WHITE);
		desktopReports.setBounds(212, 127, 1519, 602);
		contentPane.add(desktopReports);
		desktopReports.setLayout(null);
		
		DailyPanel = DisplayDailyReport();
		WeeklyPanel_1 = DisplayWeeklyReport();
		
		JLabel lblClinicName_1 = new JLabel("Clinic name:");
		lblClinicName_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblClinicName_1.setBounds(350, 25, 79, 28);
		contentPane.add(lblClinicName_1);
		
		JLabel lblClinicNum = new JLabel("Clinic num:");
		lblClinicNum.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblClinicNum.setBounds(350, 64, 79, 28);
		contentPane.add(lblClinicNum);
		
		btnCreateDailyReport = new JButton("Create Daily Report");
		btnCreateDailyReport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CreateDailyReport();
			}
		});
		btnCreateDailyReport.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnCreateDailyReport.setBounds(10, 283, 192, 39);
		contentPane.add(btnCreateDailyReport);
		
		MainTxtClinicNum = new JTextField();
		MainTxtClinicNum.setText("22");
		MainTxtClinicNum.setFont(new Font("Tahoma", Font.PLAIN, 14));
		MainTxtClinicNum.setColumns(10);
		MainTxtClinicNum.setBounds(429, 65, 110, 28);
		contentPane.add(MainTxtClinicNum);
		
		btnCreateMonthlyreport = new JButton("Create Weekly Report");
		btnCreateMonthlyreport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CreateWeeklyReport();				
			}
		});
		btnCreateMonthlyreport.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnCreateMonthlyreport.setBounds(10, 332, 192, 39);
		contentPane.add(btnCreateMonthlyreport);
		
		MainTxtClinicName = new JTextField();
		MainTxtClinicName.setText("2016-06-05");
		MainTxtClinicName.setFont(new Font("Tahoma", Font.PLAIN, 14));
		MainTxtClinicName.setColumns(10);
		MainTxtClinicName.setBounds(429, 25, 110, 28);
		contentPane.add(MainTxtClinicName);
		
		JButton btnCreateMonthlyReport = new JButton("Create Monthly Report");
		btnCreateMonthlyReport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				createMonthlyReport();
			}
		});
		btnCreateMonthlyReport.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnCreateMonthlyReport.setBounds(10, 382, 192, 39);
		contentPane.add(btnCreateMonthlyReport);
	}// end initComponent
	
	
	private void createMonthlyReport(){
		//select * from Daily_Report where date
		String currDate;
		Date today = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
		currDate = sdf.format(today);
			//	calendar.add(Calendar.DATE, 1 - today);				~~~~~~~~~
		inputQuery="pulllike:Daily_Report:date,"+currDate;
		MonthlyReportController.CalcMonthlyDetails(inputQuery);
		inputQuery="";
		
		// Calc leave patients
		inputQuery="pulllike:patients:leave_date,0000-00-00";
		MonthlyReportController.CalcMonthlyDetails(inputQuery);
		inputQuery="";
		
		// Calc amount of patients that didn't arrived to appointment
		// stop
		
		
		
		
		
		inputQuery="pulllike:patients:leave_date,0000-00-00";
		MonthlyReportController.CalcMonthlyDetails(inputQuery);
		inputQuery="";
		
		inputQuery="push:daily_report:";
		inputQuery=inputQuery+"clinic_num,";//+DailyReportController.dailyRepEnt.GetClinicNum();
		inputQuery=inputQuery+",month_date,"+currDate;
		inputQuery=inputQuery+",monthly_patient_amount,"+DailyReportController.dailyRepEnt.GetDayNum();
		inputQuery=inputQuery+",monthly_patients_amount_avg,"+DailyReportController.dailyRepEnt.GetPatientsAmount();
		inputQuery=inputQuery+",monthly_patients_amount_max,"+DailyReportController.dailyRepEnt.GetWaitingTimeAvg();
		inputQuery=inputQuery+",monthly_patients_amount_min,"+DailyReportController.dailyRepEnt.GetWaitingTimeMax();
		inputQuery=inputQuery+",monthly_patients_amount_deviation,"+DailyReportController.dailyRepEnt.GetWaitingTimeMin();
		inputQuery=inputQuery+",Waiting_time_deviation,"+DailyReportController.dailyRepEnt.GetWwaitingTimeDeviation();
		inputQuery=inputQuery+",left_patients_amount,"+DailyReportController.dailyRepEnt.GetWwaitingTimeDeviation();
		inputQuery=inputQuery+",not_reached_amount,"+DailyReportController.dailyRepEnt.GetWwaitingTimeDeviation();
		inputQuery=inputQuery+",waiting_month_0,"+DailyReportController.dailyRepEnt.GetWaiting_month_0();
		inputQuery=inputQuery+",waiting_month_1,"+DailyReportController.dailyRepEnt.GetWaiting_month_1();
		inputQuery=inputQuery+",waiting_month_2,"+DailyReportController.dailyRepEnt.GetWaiting_month_2();
		inputQuery=inputQuery+",waiting_month_3,"+DailyReportController.dailyRepEnt.GetWaiting_month_3();
		inputQuery=inputQuery+",start_week_date,"+DailyReportController.dailyRepEnt.GetStart_week_date();
	//	DailyReportController.InsertMonthlyDetailsToDB(inputQuery);
		inputQuery="";
	}
	
	
	

	private String CalcFirstDateInWeek(){
		int today;
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Calendar calendar = Calendar.getInstance();
        today = calendar.get(Calendar.DAY_OF_WEEK);
        calendar.add(Calendar.DATE, 1 - today);
        return dateFormat.format(calendar.getTime());
	}
	
	
	//display the type of monthly report
	private void createEvents1() {
		btnViewMonthlyReport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("btnViewMonthlyReport");
			/*	DailyPanel.setVisible(false);
				WeeklyPanel.setVisible(false);
				MonthlyPanel.setVisible(true);
			*/
		/*		if (WeekRep != null )
					WeekRep.dispose();/// close week report if open
				if (Rep == null || Rep.isClosed())
				Rep = new TypeOfMonthlyReports();  ////  �� ����� ������ �� ������ ����� ������ 
				desktopReports.add(Rep);/// ���� �� ���� ����
				Rep.show(); // ������ �����
			*/
			}
		});
	}// end createEvents1

	/*
	//for weekly report
	private void createEvents2() {
		btnViewWeeklyReport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("!ERR");
			//	DailyPanel.setVisible(false);
			//	WeeklyPanel.setVisible(true);
			//	MonthlyPanel.setVisible(false);
			}
		});
	}
	*/
	
	private void DisplayMontlyDate(){
		ArrayList<String> dates;
		String[] dmy;
		String date;
		inputQuery="pull:weekly_report";
		WeeklyReportController.pullWeeklyDates(inputQuery);
		dates = WeeklyReportController.week_rep.getExistDates();
		for(int i=0; i<dates.size(); i++)
		{
			System.out.println("dates.get("+i+"): "+dates.get(i));
			dmy = dates.get(i).split("-");
			System.out.println("day: "+dmy[2] + ", month: " + dmy[1] + ", year: " + dmy[0]);
			date = dmy[2]+"/"+dmy[1]+"/"+dmy[0];
			cbWeeklyDate.addItem(date);
			
		}
		
		/*int size = WeeklyReportController.week_rep.getDatesAmount();
		dates = WeeklyReportController.week_rep.getExistDates();
		System.out.println("~~\nsize= " + size);
		for(int i=0; i<dates.size(); i++)
		{
			System.out.println("dates.get("+i+"): "+dates.get(i));
		//	dmy = dates.get(i).split("-");
		//	System.out.println("day: "+dmy[3] + ", month: " + dmy[2] + ", year: " + dmy[1]);
		}
		System.out.println("\nend\n");
		*/
		/*
		 * float fVal;
		String date="", monthDate="", yearDate;
		yearDate = "2016";
		
		int index = cbMonth.getSelectedIndex()+1;
		monthDate = (index < 10)? "0" : "";
		monthDate = monthDate + Integer.toString(index);
		
		index = cbDay.getSelectedIndex()+1;
		date = (index < 10)? "0": "";
		date = date + Integer.toString(index);
		 */
		
	}
	
	
	private JPanel DisplayDailyReport(){
		DailyPanel = new JPanel();
		DailyPanel.setBounds(0, 11, 499, 317);
		DailyPanel.setVisible(true); // false
		desktopReports.add(DailyPanel);
		
		JLabel lblNewLabel = new JLabel("Daily-Report");
		lblNewLabel.setBounds(188, 11, 133, 35);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));
		DailyPanel.setLayout(null);
		DailyPanel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Choose date:");
		lblNewLabel_1.setBounds(24, 67, 110, 28);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		DailyPanel.add(lblNewLabel_1);
		
		dateField = new JTextField();
		dateField.setText("2016-06-01");
		dateField.setBounds(132, 67, 110, 28);
		dateField.setFont(new Font("Tahoma", Font.PLAIN, 14));
		Date dt = new Date();									// Dell
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); // dell
		dateField.setText(sdf.format(dt));		// dell
		DailyPanel.add(dateField);
		dateField.setColumns(10);
		
		JButton btnNewButton = new JButton("Create report");
		btnNewButton.setBounds(252, 107, 130, 28);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int dVal;
				
				inputQuery="pullbykey:appointments:app_date,"+dateField.getText();
				inputQuery=inputQuery + ",status,arrived,clinic_num,"+clinicField.getText();
				DailyReportController.ClacDailyDetails(inputQuery);	
				inputQuery="";
					
				DailyReportController.dailyRepEnt.SetDate(dateField.getText());
				DailyReportController.dailyRepEnt.SetClinicNum(Integer.parseInt(clinicField.getText()));
				DailyReportController.dailyRepEnt.SetStart_week_date(CalcFirstDateInWeek());
				
				inputQuery="push:daily_report:";
				inputQuery=inputQuery+"clinic_num,"+DailyReportController.dailyRepEnt.GetClinicNum();
				inputQuery=inputQuery+",date,"+DailyReportController.dailyRepEnt.GetDate();
				inputQuery=inputQuery+",Day_name,"+DailyReportController.dailyRepEnt.GetDayNum();
				inputQuery=inputQuery+",Patient_amount,"+DailyReportController.dailyRepEnt.GetPatientsAmount();
				inputQuery=inputQuery+",Waiting_time_avg,"+DailyReportController.dailyRepEnt.GetWaitingTimeAvg();
				inputQuery=inputQuery+",Waiting_time_max,"+DailyReportController.dailyRepEnt.GetWaitingTimeMax();
				inputQuery=inputQuery+",Waiting_time_min,"+DailyReportController.dailyRepEnt.GetWaitingTimeMin();
				inputQuery=inputQuery+",Waiting_time_deviation,"+DailyReportController.dailyRepEnt.GetWwaitingTimeDeviation();
				inputQuery=inputQuery+",waiting_month_0,"+DailyReportController.dailyRepEnt.GetWaiting_month_0();
				inputQuery=inputQuery+",waiting_month_1,"+DailyReportController.dailyRepEnt.GetWaiting_month_1();
				inputQuery=inputQuery+",waiting_month_2,"+DailyReportController.dailyRepEnt.GetWaiting_month_2();
				inputQuery=inputQuery+",waiting_month_3,"+DailyReportController.dailyRepEnt.GetWaiting_month_3();
				inputQuery=inputQuery+",start_week_date,"+DailyReportController.dailyRepEnt.GetStart_week_date();
				DailyReportController.InsertDailyDetailsToDB(inputQuery);
				inputQuery="";
				System.out.println();
				
				// to block also??
				dVal = DailyReportController.dailyRepEnt.GetPatientsAmount();
				lblPatientAmount.setText(Integer.toString(dVal));
				dVal = DailyReportController.dailyRepEnt.GetWaiting_month_0();
				lbl0.setText(Integer.toString(dVal));
				dVal = DailyReportController.dailyRepEnt.GetWaiting_month_1();
				lbl1.setText(Integer.toString(dVal));
				dVal = DailyReportController.dailyRepEnt.GetWaiting_month_2();
				lbl2.setText(Integer.toString(dVal));
				dVal = DailyReportController.dailyRepEnt.GetWaiting_month_3();
				lbl3.setText(Integer.toString(dVal));
				
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 15));
		DailyPanel.add(btnNewButton);
		
		JLabel lblPatients = new JLabel("Patients amount:");
		lblPatients.setBounds(24, 156, 133, 19);
		lblPatients.setFont(new Font("Tahoma", Font.PLAIN, 15));
		DailyPanel.add(lblPatients);
		
		lblPatientAmount = new JLabel("0");
		lblPatientAmount.setBounds(168, 156, 78, 19);
		lblPatientAmount.setFont(new Font("Tahoma", Font.PLAIN, 15));
		DailyPanel.add(lblPatientAmount);
		
		label_5 = new JLabel("Waiting time for appointment:");
		label_5.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_5.setBounds(22, 186, 221, 29);
		DailyPanel.add(label_5);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null},
			},
			new String[] {
				"0-30 days", "New column", "New column", "New column", "New column"
			}
		));
		table.setColumnSelectionAllowed(true);
		table.setCellSelectionEnabled(true);
		table.setForeground(Color.MAGENTA);
		table.setSurrendersFocusOnKeystroke(true);
		table.setBounds(419, 229, -209, -84);
		DailyPanel.add(table);
		
		JLabel lblDays = new JLabel("0 - 1");
		lblDays.setHorizontalAlignment(SwingConstants.CENTER);
		lblDays.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblDays.setForeground(Color.BLACK);
		lblDays.setBackground(Color.YELLOW);
		lblDays.setBounds(140, 239, 78, 19);
		DailyPanel.add(lblDays);
		
		JLabel lblDays_1 = new JLabel("1 - 2");
		lblDays_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblDays_1.setForeground(Color.BLACK);
		lblDays_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblDays_1.setBackground(Color.YELLOW);
		lblDays_1.setBounds(228, 239, 78, 19);
		DailyPanel.add(lblDays_1);
		
		lblDays_2 = new JLabel("2 - 3 ");
		lblDays_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblDays_2.setForeground(Color.BLACK);
		lblDays_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblDays_2.setBackground(Color.YELLOW);
		lblDays_2.setBounds(316, 239, 78, 19);
		DailyPanel.add(lblDays_2);
		
		lblDays_3 = new JLabel("3 +");
		lblDays_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblDays_3.setForeground(Color.BLACK);
		lblDays_3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblDays_3.setBackground(Color.YELLOW);
		lblDays_3.setBounds(411, 239, 40, 19);
		DailyPanel.add(lblDays_3);
		
		lblWaitingTime = new JLabel("Patients amount:");
		lblWaitingTime.setForeground(Color.BLACK);
		lblWaitingTime.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblWaitingTime.setBackground(Color.YELLOW);
		lblWaitingTime.setBounds(22, 269, 118, 19);
		DailyPanel.add(lblWaitingTime);
		
		lbl0 = new JLabel("0");
		lbl0.setHorizontalAlignment(SwingConstants.CENTER);
		lbl0.setForeground(Color.BLACK);
		lbl0.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lbl0.setBackground(Color.YELLOW);
		lbl0.setBounds(140, 269, 66, 19);
		DailyPanel.add(lbl0);
		
		lbl1 = new JLabel("0");
		lbl1.setHorizontalAlignment(SwingConstants.CENTER);
		lbl1.setForeground(Color.BLACK);
		lbl1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lbl1.setBackground(Color.YELLOW);
		lbl1.setBounds(224, 269, 66, 19);
		DailyPanel.add(lbl1);
		
		lbl2 = new JLabel("0");
		lbl2.setHorizontalAlignment(SwingConstants.CENTER);
		lbl2.setForeground(Color.BLACK);
		lbl2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lbl2.setBackground(Color.YELLOW);
		lbl2.setBounds(316, 269, 66, 19);
		DailyPanel.add(lbl2);
		
		lbl3 = new JLabel("0");
		lbl3.setHorizontalAlignment(SwingConstants.CENTER);
		lbl3.setForeground(Color.BLACK);
		lbl3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lbl3.setBackground(Color.YELLOW);
		lbl3.setBounds(403, 269, 46, 19);
		DailyPanel.add(lbl3);
		
		lblMonth = new JLabel("Months:");
		lblMonth.setForeground(Color.BLACK);
		lblMonth.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblMonth.setBackground(Color.YELLOW);
		lblMonth.setBounds(22, 239, 98, 19);
		DailyPanel.add(lblMonth);
		
		JLabel lblClinicName = new JLabel("Clinic num:");
		lblClinicName.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblClinicName.setBounds(24, 106, 110, 28);
		DailyPanel.add(lblClinicName);
		
		clinicField = new JTextField();
		clinicField.setText("22");
		clinicField.setFont(new Font("Tahoma", Font.PLAIN, 14));
		clinicField.setColumns(10);
		clinicField.setBounds(132, 106, 110, 28);
		DailyPanel.add(clinicField);
		
		JButton btnViewDailyReport = new JButton("View Daily Report");
		btnViewDailyReport.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnViewDailyReport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("btnViewDailyReport");
			/*	DailyPanel.setVisible(true);
				WeeklyPanel.setVisible(false);
				MonthlyPanel.setVisible(false);
			*/
			}
		});
		btnViewDailyReport.setBounds(10, 233, 192, 39);
		contentPane.add(btnViewDailyReport);
		
		return DailyPanel;
	}
	
	private JPanel DisplayWeeklyReport(){
		WeeklyPanel_1 = new JPanel();
		WeeklyPanel_1.setBounds(532, 18, 427, 467);
		WeeklyPanel_1.setLayout(null);
		WeeklyPanel_1.setVisible(true); //false
		desktopReports.add(WeeklyPanel_1);
		WeeklyPanel_1.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Weekly Report", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		

		cbWeeklyDate = new JComboBox<String>();
		cbWeeklyDate.setToolTipText("Name of clinic");
		cbWeeklyDate.setFont(new Font("Tahoma", Font.PLAIN, 15));
		cbWeeklyDate.setBounds(140, 27, 194, 24);
		cbWeeklyDate.addItemListener(new java.awt.event.ItemListener() {
			public void itemStateChanged(java.awt.event.ItemEvent e) {
				int index = cbWeeklyDate.getSelectedIndex();
				String reportDate = WeeklyReportController.week_rep.getExistDateByIndex(index);
				// get into fields all details of clinic number index.
			//	dateParts = reportDate.split("-"); // dateParts[0] = day, dateParts[1] = month, dateParts[2] = year
			//	fullDate = dateParts[2]+"-"+dateParts[1]+"-"+dateParts[0];
				System.out.println("reportDate = " + reportDate);
			
				inputQuery="pullbykey:weekly_report:start_week_date," + reportDate;
				WeeklyReportController.ShowByDate(inputQuery);
				inputQuery="";
				
				lblpAmount.setText(Integer.toString(WeeklyReportController.week_rep.getPatientsAmount()));
				lblAvg.setText(Float.toString(WeeklyReportController.week_rep.getWeeklyWaitingTimeAvg()));
				lblMax.setText(Integer.toString(WeeklyReportController.week_rep.getWeeklyWaitingTimeMax()));
				lblMin.setText(Integer.toString(WeeklyReportController.week_rep.getWeeklyWaitingTimeMin()));
				lblDev.setText(Float.toString(WeeklyReportController.week_rep.getWeeklyWaitingTimeDeviation()));
				lblm0.setText(Integer.toString(WeeklyReportController.week_rep.getWaitingMonth_0()));
				lblm1.setText(Integer.toString(WeeklyReportController.week_rep.getWaitingMonth_1()));
				lblm2.setText(Integer.toString(WeeklyReportController.week_rep.getWaitingMonth_2()));
				lblm3.setText(Integer.toString(WeeklyReportController.week_rep.getWaitingMonth_3()));
				
				/*
				 * float fVal;
		int index = cbMonth.getSelectedIndex()+1;
		monthDate = (index < 10)? "0" : "";
		monthDate = monthDate + Integer.toString(index);
		
		index = cbDay.getSelectedIndex()+1;
		date = (index < 10)? "0": "";
		date = date + Integer.toString(index);
/*
		inputQuery="pullbykey:weekly_report:"+ "start_week_date," + date;
		WeeklyReportController.ShowByDate(inputQuery);
		inputQuery="";
		
		fVal = WeeklyReportController.week_rep.getAvgWaitingTimeForAppointment();
		lblAvg.setText(Float.toString(fVal));
	*/	
	/* ������ ���� ������� ������ �����, �� 2 �����:
		 * 1. ����� ������ �Entity - �����, ��� ��� ���� �����, �� ����� ���� �-7 ����, ����� �� ���� �������� ������� ������ ������ �������.
		 * 2. ������ �����: ��� �� �� ����� ����� ��� ���� ���� ������ �� ����� ���� ���� ����� ������, ��� ����� ������ ������ �� ������ (��� ������ ���� �� �� �����)
		 * */
			}
		});
		MonthlyPanel = DisplayMonthlyReport();
		WeeklyPanel_1.add(cbWeeklyDate);
		
		label_2 = new JLabel("Weekly report ");
		label_2.setHorizontalAlignment(SwingConstants.CENTER);
		label_2.setFont(new Font("Tahoma", Font.BOLD, 16));
		label_2.setBounds(134, 126, 144, 34);
		WeeklyPanel_1.add(label_2);
		
		label_3 = new JLabel("Patients amount:");
		label_3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_3.setBounds(10, 177, 127, 14);
		WeeklyPanel_1.add(label_3);
		
		label_4 = new JLabel("Waiting time for appointment:");
		label_4.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_4.setBounds(10, 205, 194, 22);
		WeeklyPanel_1.add(label_4);
		
		button_2 = new JButton("Back");
		button_2.setBounds(298, 415, 108, 41);
		WeeklyPanel_1.add(button_2);
		
		label_6 = new JLabel("- Maximum value:");
		label_6.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_6.setBounds(77, 270, 145, 23);
		WeeklyPanel_1.add(label_6);
		
		label_7 = new JLabel("- Average value:");
		label_7.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_7.setBounds(77, 230, 145, 20);
		WeeklyPanel_1.add(label_7);
		
		label_8 = new JLabel("- Minimum value:");
		label_8.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_8.setBounds(77, 249, 145, 23);
		WeeklyPanel_1.add(label_8);
		
		label_9 = new JLabel("- Standard deviation:");
		label_9.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_9.setBounds(78, 291, 144, 20);
		WeeklyPanel_1.add(label_9);
		
		label_10 = new JLabel("Patients amount:");
		label_10.setForeground(Color.BLACK);
		label_10.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_10.setBackground(Color.YELLOW);
		label_10.setBounds(10, 377, 118, 19);
		WeeklyPanel_1.add(label_10);
		
		label_11 = new JLabel("0 - 1");
		label_11.setHorizontalAlignment(SwingConstants.CENTER);
		label_11.setForeground(Color.BLACK);
		label_11.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_11.setBackground(Color.YELLOW);
		label_11.setBounds(134, 347, 60, 19);
		WeeklyPanel_1.add(label_11);
		
		lblm0 = new JLabel("0");
		lblm0.setHorizontalAlignment(SwingConstants.CENTER);
		lblm0.setForeground(Color.BLACK);
		lblm0.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblm0.setBackground(Color.YELLOW);
		lblm0.setBounds(128, 377, 66, 19);
		WeeklyPanel_1.add(lblm0);
		
		label_13 = new JLabel("1 - 2");
		label_13.setHorizontalAlignment(SwingConstants.CENTER);
		label_13.setForeground(Color.BLACK);
		label_13.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_13.setBackground(Color.YELLOW);
		label_13.setBounds(204, 347, 60, 19);
		WeeklyPanel_1.add(label_13);
		
		lblm1 = new JLabel("0");
		lblm1.setHorizontalAlignment(SwingConstants.CENTER);
		lblm1.setForeground(Color.BLACK);
		lblm1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblm1.setBackground(Color.YELLOW);
		lblm1.setBounds(204, 377, 66, 19);
		WeeklyPanel_1.add(lblm1);
		
		label_15 = new JLabel("2 - 3");
		label_15.setHorizontalAlignment(SwingConstants.CENTER);
		label_15.setForeground(Color.BLACK);
		label_15.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_15.setBackground(Color.YELLOW);
		label_15.setBounds(274, 347, 60, 19);
		WeeklyPanel_1.add(label_15);
		
		lblm2 = new JLabel("0");
		lblm2.setHorizontalAlignment(SwingConstants.CENTER);
		lblm2.setForeground(Color.BLACK);
		lblm2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblm2.setBackground(Color.YELLOW);
		lblm2.setBounds(268, 377, 66, 19);
		WeeklyPanel_1.add(lblm2);
		
		label_17 = new JLabel("3 + ");
		label_17.setHorizontalAlignment(SwingConstants.CENTER);
		label_17.setForeground(Color.BLACK);
		label_17.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_17.setBackground(Color.YELLOW);
		label_17.setBounds(344, 347, 52, 19);
		WeeklyPanel_1.add(label_17);
		
		lblm3 = new JLabel("0");
		lblm3.setHorizontalAlignment(SwingConstants.CENTER);
		lblm3.setForeground(Color.BLACK);
		lblm3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblm3.setBackground(Color.YELLOW);
		lblm3.setBounds(336, 377, 60, 19);
		WeeklyPanel_1.add(lblm3);
		
		label_19 = new JLabel("Months:");
		label_19.setForeground(Color.BLACK);
		label_19.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_19.setBackground(Color.YELLOW);
		label_19.setBounds(66, 347, 60, 19);
		WeeklyPanel_1.add(label_19);
		
		lblpAmount = new JLabel("0");
		lblpAmount.setHorizontalAlignment(SwingConstants.CENTER);
		lblpAmount.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblpAmount.setBounds(223, 179, 46, 14);
		WeeklyPanel_1.add(lblpAmount);
		
		lblAvg = new JLabel("0");
		lblAvg.setHorizontalAlignment(SwingConstants.CENTER);
		lblAvg.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblAvg.setBounds(223, 235, 46, 14);
		WeeklyPanel_1.add(lblAvg);
		
		lblMin = new JLabel("0");
		lblMin.setHorizontalAlignment(SwingConstants.CENTER);
		lblMin.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblMin.setBounds(223, 255, 46, 14);
		WeeklyPanel_1.add(lblMin);
		
		lblMax = new JLabel("0");
		lblMax.setHorizontalAlignment(SwingConstants.CENTER);
		lblMax.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblMax.setBounds(223, 276, 46, 14);
		WeeklyPanel_1.add(lblMax);
		
		lblDev = new JLabel("0");
		lblDev.setHorizontalAlignment(SwingConstants.CENTER);
		lblDev.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblDev.setBounds(223, 296, 46, 14);
		WeeklyPanel_1.add(lblDev);
		
		lblChooseDate = new JLabel("Choose date:");
		lblChooseDate.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblChooseDate.setBounds(47, 28, 100, 22);
		WeeklyPanel_1.add(lblChooseDate);

		
		JButton btnViewDailyReport = new JButton("View Daily Report");
		btnViewDailyReport.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnViewDailyReport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("btnViewDailyReport");
			/*	
				DailyPanel.setVisible(true);
				WeeklyPanel.setVisible(false);
				MonthlyPanel.setVisible(false);
			*/
			}
		});
		btnViewDailyReport.setBounds(10, 233, 192, 39);
		contentPane.add(btnViewDailyReport);
		
		
		return WeeklyPanel_1;
	}
		
	private JPanel DisplayMonthlyReport(){
		MonthlyPanel = new JPanel();
		MonthlyPanel.setLayout(null);
		MonthlyPanel.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Monthly Report", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		MonthlyPanel.setBounds(1031, 18, 457, 449);
		MonthlyPanel.setVisible(true);//false
		desktopReports.add(MonthlyPanel);
		
		label_28 = new JLabel("Date : ");
		label_28.setBounds(10, 29, 46, 14);
		MonthlyPanel.add(label_28);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(51, 26, 86, 20);
		MonthlyPanel.add(textField);
		
		label_29 = new JLabel("Monthly Report");
		label_29.setFont(new Font("Tahoma", Font.BOLD, 16));
		label_29.setBounds(134, 57, 168, 33);
		MonthlyPanel.add(label_29);
		
		label_30 = new JLabel("Left patients amount:");
		label_30.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_30.setBounds(10, 347, 194, 14);
		MonthlyPanel.add(label_30);
		
		label_31 = new JLabel("Not reached patient amount");
		label_31.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_31.setBounds(10, 375, 212, 14);
		MonthlyPanel.add(label_31);
		
		button = new JButton("Back");
		button.setBounds(324, 397, 108, 41);
		MonthlyPanel.add(button);
		
		label_32 = new JLabel("Patients amount:");
		label_32.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_32.setBounds(10, 101, 127, 14);
		MonthlyPanel.add(label_32);
		
		label_33 = new JLabel("0");
		label_33.setHorizontalAlignment(SwingConstants.CENTER);
		label_33.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_33.setBounds(223, 103, 46, 14);
		MonthlyPanel.add(label_33);
		
		label_34 = new JLabel("Waiting time for appointment:");
		label_34.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_34.setBounds(10, 129, 194, 14);
		MonthlyPanel.add(label_34);
		
		label_35 = new JLabel("- Average value:");
		label_35.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_35.setBounds(77, 154, 145, 20);
		MonthlyPanel.add(label_35);
		
		label_36 = new JLabel("- Minimum value:");
		label_36.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_36.setBounds(77, 173, 145, 23);
		MonthlyPanel.add(label_36);
		
		label_37 = new JLabel("- Maximum value:");
		label_37.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_37.setBounds(77, 194, 145, 23);
		MonthlyPanel.add(label_37);
		
		label_38 = new JLabel("- Standard deviation:");
		label_38.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_38.setBounds(78, 215, 144, 20);
		MonthlyPanel.add(label_38);
		
		label_39 = new JLabel("0");
		label_39.setHorizontalAlignment(SwingConstants.CENTER);
		label_39.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_39.setBounds(223, 220, 46, 14);
		MonthlyPanel.add(label_39);
		
		label_40 = new JLabel("0");
		label_40.setHorizontalAlignment(SwingConstants.CENTER);
		label_40.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_40.setBounds(223, 200, 46, 14);
		MonthlyPanel.add(label_40);
		
		label_41 = new JLabel("0");
		label_41.setHorizontalAlignment(SwingConstants.CENTER);
		label_41.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_41.setBounds(223, 179, 46, 14);
		MonthlyPanel.add(label_41);
		
		label_42 = new JLabel("0");
		label_42.setHorizontalAlignment(SwingConstants.CENTER);
		label_42.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_42.setBounds(223, 159, 46, 14);
		MonthlyPanel.add(label_42);
		
		label_43 = new JLabel("Month:");
		label_43.setForeground(Color.BLACK);
		label_43.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_43.setBackground(Color.YELLOW);
		label_43.setBounds(77, 271, 60, 19);
		MonthlyPanel.add(label_43);
		
		label_44 = new JLabel(" Patients amount:");
		label_44.setForeground(Color.BLACK);
		label_44.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_44.setBackground(Color.YELLOW);
		label_44.setBounds(10, 301, 118, 19);
		MonthlyPanel.add(label_44);
		
		label_45 = new JLabel("0");
		label_45.setHorizontalAlignment(SwingConstants.CENTER);
		label_45.setForeground(Color.BLACK);
		label_45.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_45.setBackground(Color.YELLOW);
		label_45.setBounds(128, 301, 66, 19);
		MonthlyPanel.add(label_45);
		
		label_46 = new JLabel("0 - 1");
		label_46.setHorizontalAlignment(SwingConstants.CENTER);
		label_46.setForeground(Color.BLACK);
		label_46.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_46.setBackground(Color.YELLOW);
		label_46.setBounds(134, 271, 60, 19);
		MonthlyPanel.add(label_46);
		
		label_47 = new JLabel("1 - 2");
		label_47.setHorizontalAlignment(SwingConstants.CENTER);
		label_47.setForeground(Color.BLACK);
		label_47.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_47.setBackground(Color.YELLOW);
		label_47.setBounds(204, 271, 60, 19);
		MonthlyPanel.add(label_47);
		
		label_48 = new JLabel("0");
		label_48.setHorizontalAlignment(SwingConstants.CENTER);
		label_48.setForeground(Color.BLACK);
		label_48.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_48.setBackground(Color.YELLOW);
		label_48.setBounds(204, 301, 66, 19);
		MonthlyPanel.add(label_48);
		
		label_49 = new JLabel("0");
		label_49.setHorizontalAlignment(SwingConstants.CENTER);
		label_49.setForeground(Color.BLACK);
		label_49.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_49.setBackground(Color.YELLOW);
		label_49.setBounds(268, 301, 66, 19);
		MonthlyPanel.add(label_49);
		
		label_50 = new JLabel("2 - 3");
		label_50.setHorizontalAlignment(SwingConstants.CENTER);
		label_50.setForeground(Color.BLACK);
		label_50.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_50.setBackground(Color.YELLOW);
		label_50.setBounds(274, 271, 60, 19);
		MonthlyPanel.add(label_50);
		
		label_51 = new JLabel("3 + ");
		label_51.setHorizontalAlignment(SwingConstants.CENTER);
		label_51.setForeground(Color.BLACK);
		label_51.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_51.setBackground(Color.YELLOW);
		label_51.setBounds(344, 271, 52, 19);
		MonthlyPanel.add(label_51);
		
		label_52 = new JLabel("0");
		label_52.setHorizontalAlignment(SwingConstants.CENTER);
		label_52.setForeground(Color.BLACK);
		label_52.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_52.setBackground(Color.YELLOW);
		label_52.setBounds(344, 301, 52, 19);
		MonthlyPanel.add(label_52);
		
		label_53 = new JLabel("0");
		label_53.setHorizontalAlignment(SwingConstants.CENTER);
		label_53.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_53.setBounds(224, 347, 46, 14);
		MonthlyPanel.add(label_53);
		
		label_54 = new JLabel("0");
		label_54.setHorizontalAlignment(SwingConstants.CENTER);
		label_54.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_54.setBounds(223, 377, 46, 14);
		MonthlyPanel.add(label_54);
		return MonthlyPanel;
	}

	private void CreateDailyReport(){
		String currDate;
		int clinicNum, DayNum;
		
		Date today = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	//	DailyReportController.dailyRepEnt.SetDate(currDate = sdf.format(today));
		
		DailyReportController.dailyRepEnt.SetDate(currDate = MainTxtClinicName.getText());	// del
		
		clinicNum = Integer.parseInt(MainTxtClinicNum.getText());
		DailyReportController.dailyRepEnt.SetClinicNum(clinicNum);
		
		Calendar calendar = Calendar.getInstance();  
        calendar.setTime(today);  
		DayNum = DayCounter++;//calendar.get(Calendar.DAY_OF_WEEK);	// DEL
		DailyReportController.dailyRepEnt.SetDayNum(DayNum);
		
		DailyReportController.dailyRepEnt.SetStart_week_date(CalcFirstDateInWeek());
		
		// Calculate the amount of patients that arrived today to appointment (in manager's clinic)
		DailyReportController.toContinue = true;
		DailyReportController.dailyRepEnt.InitAll();
		inputQuery="pullbykey:appointments:app_date," + currDate;
		inputQuery=inputQuery + ",status,arrived,clinic_num," + clinicNum;
		DailyReportController.ClacDailyDetails(inputQuery);
		inputQuery="";
		
		if(!DailyReportController.toContinue) // no appointments for today
			DailyReportController.dailyRepEnt.InitAll();
		DailyReportController.toContinue = true;

		// Update DB (table daily_report) with the daily report's details.
		inputQuery="push:daily_report:";
		inputQuery=inputQuery+"date,"+DailyReportController.dailyRepEnt.GetDate();
		inputQuery=inputQuery+",clinic_num,"+DailyReportController.dailyRepEnt.GetClinicNum();
		inputQuery=inputQuery+",Day_num,"+DailyReportController.dailyRepEnt.GetDayNum();
		inputQuery=inputQuery+",Patient_amount,"+DailyReportController.dailyRepEnt.GetPatientsAmount();
		inputQuery=inputQuery+",Waiting_time_avg,"+DailyReportController.dailyRepEnt.GetWaitingTimeAvg();
		inputQuery=inputQuery+",Waiting_time_max,"+DailyReportController.dailyRepEnt.GetWaitingTimeMax();
		inputQuery=inputQuery+",Waiting_time_min,"+DailyReportController.dailyRepEnt.GetWaitingTimeMin();
		inputQuery=inputQuery+",Waiting_time_deviation,"+DailyReportController.dailyRepEnt.GetWwaitingTimeDeviation();
		inputQuery=inputQuery+",waiting_month_0,"+DailyReportController.dailyRepEnt.GetWaiting_month_0();
		inputQuery=inputQuery+",waiting_month_1,"+DailyReportController.dailyRepEnt.GetWaiting_month_1();
		inputQuery=inputQuery+",waiting_month_2,"+DailyReportController.dailyRepEnt.GetWaiting_month_2();
		inputQuery=inputQuery+",waiting_month_3,"+DailyReportController.dailyRepEnt.GetWaiting_month_3();
		inputQuery=inputQuery+",start_week_date,"+DailyReportController.dailyRepEnt.GetStart_week_date();
		DailyReportController.InsertDailyDetailsToDB(inputQuery);
		inputQuery="";
		
		DailyReportController.SaveReportInWeekly();
	}
	
	private void CreateWeeklyReport(){
		String currDate, startWeekDate, month_date;
		int clinicNum, DayIndex, weekInMonthIndex;
		
		clinicNum = Integer.parseInt(MainTxtClinicNum.getText());
		WeeklyReportController.week_rep.setClinicNum(clinicNum);
			
		Date today = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		currDate = sdf.format(today);
	
		Calendar calendar = Calendar.getInstance();  
        calendar.setTime(today);
        DayIndex = calendar.get(Calendar.DAY_OF_WEEK);
        
		if(DayIndex == 7) // Produce report on Saturday
		{
			weekInMonthIndex = calendar.get(Calendar.WEEK_OF_MONTH);
			WeeklyReportController.week_rep.setWeekNum(weekInMonthIndex);
			
			startWeekDate = CalcFirstDateInWeek();
			WeeklyReportController.week_rep.setStartWeekDate(startWeekDate);
			
			month_date = calendar.get(Calendar.YEAR)+"-"+calendar.get(Calendar.MONTH);		
			WeeklyReportController.week_rep.setMonthDate(month_date);
			
			WeeklyReportController.MakeWeeklyReport();
			
			// InsertToDB
			inputQuery="push:weekly_report:";
			inputQuery=inputQuery+"start_week_date,"+WeeklyReportController.week_rep.getStartWeekDate();
			inputQuery=inputQuery+",clinic_num,"+WeeklyReportController.week_rep.getClinicNum();
			inputQuery=inputQuery+",Week_num,"+WeeklyReportController.week_rep.getWeekNum();
			inputQuery=inputQuery+",patients_amount,"+WeeklyReportController.week_rep.getPatientsAmount();
			inputQuery=inputQuery+",Weekly_waiting_time_avg,"+WeeklyReportController.week_rep.getWeeklyWaitingTimeAvg();
			inputQuery=inputQuery+",Weekly_waiting_time_max,"+WeeklyReportController.week_rep.getWeeklyWaitingTimeMax();
			inputQuery=inputQuery+",Weekly_waiting_time_min,"+WeeklyReportController.week_rep.getWeeklyWaitingTimeMin();
			inputQuery=inputQuery+",Weekly_waiting_time_deviation,"+WeeklyReportController.week_rep.getWeeklyWaitingTimeDeviation();
			inputQuery=inputQuery+",Whole_Partial,"+WeeklyReportController.week_rep.getWhole_Partial();
			inputQuery=inputQuery+",waiting_month_0,"+WeeklyReportController.week_rep.getWaitingMonth_0();
			inputQuery=inputQuery+",waiting_month_1,"+WeeklyReportController.week_rep.getWaitingMonth_1();
			inputQuery=inputQuery+",waiting_month_2,"+WeeklyReportController.week_rep.getWaitingMonth_2();
			inputQuery=inputQuery+",waiting_month_3,"+WeeklyReportController.week_rep.getWaitingMonth_3();
			inputQuery=inputQuery+",month_date,"+WeeklyReportController.week_rep.getMonthDate();
			WeeklyReportController.InsertWeeklyDetailsToDB(inputQuery);
			inputQuery="";
			
			
		}
		else{
			// "Cannot produce weekly report in the middle of the week."
		}
		
		
		
		
		
	}
}
