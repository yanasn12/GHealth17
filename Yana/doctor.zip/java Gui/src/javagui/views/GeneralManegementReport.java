package javagui.views;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Color;

import javax.swing.ImageIcon;

import java.awt.Toolkit;

import javax.swing.JButton;

import java.awt.Font;

import javax.swing.SwingConstants;
import javax.swing.JDesktopPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;

import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.JTextField;

import Entitys.Daily_Report_Entity;
import controllers.ClinicWeeklyReport;
import controllers.DailyReportController;

import javax.swing.border.TitledBorder;
import javax.swing.UIManager;
import javax.swing.JToggleButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class GeneralManegementReport extends JFrame {
	
	private JPanel contentPane;
	private JDesktopPane desktopReports;
	private JButton btnViewMonthlyReport;
	private TypeOfMonthlyReports Rep;
	public WeeklyReport WeekRep;
	private JButton button;
	private JTextField dateField;
	private JPanel DailyPanel;
	private JLabel lblPatientAmount;
	private String inputQuery;
	private JLabel label_5;
	private JTable table;
	private JLabel lblDays_2;
	private JLabel lblDays_3;
	private JLabel lblWaitingTime;
	private JLabel lbl0;
	private JLabel lbl1;
	private JLabel lbl2;
	private JLabel lbl3;
	private JLabel lblMonth;
	private JTextField clinicField;
	//////////////////private MonthlyReports Rep;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GeneralManegementReport frame = new GeneralManegementReport();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GeneralManegementReport() {
		initComponent(); //// ����� �� INIT ��� �� �� �� ������ ��������
		createEvents1();/// ����� ������- ���� ����
		createEvents2();
		//createEvents3();
	}
	///////// init component of desktop reports
	private void initComponent() {
		//	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	//	setBounds(0, 0, 810, 775);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(GeneralManegementReport.class.getResource("/javagui/resources/GHealthlogo.png")));
		label.setBounds(113, 25, 242, 68);
		contentPane.add(label);
		
		button = new JButton("View weekly reports");//////////////////////////////////////////////////////////////////////////
		
		
		
		button.setIcon(new ImageIcon(GeneralManegementReport.class.getResource("/javagui/resources/img16x16/reports.png")));
		button.setHorizontalAlignment(SwingConstants.LEFT);
		button.setForeground(Color.BLUE);
		button.setFont(new Font("Tahoma", Font.BOLD, 11));
		button.setBackground(Color.WHITE);
		button.setBounds(10, 133, 192, 39);
		contentPane.add(button);
		
		btnViewMonthlyReport = new JButton("View monthly report ");
		
		btnViewMonthlyReport.setIcon(new ImageIcon(GeneralManegementReport.class.getResource("/javagui/resources/img16x16/reports.png")));
		btnViewMonthlyReport.setHorizontalAlignment(SwingConstants.LEFT);
		btnViewMonthlyReport.setForeground(Color.BLUE);
		btnViewMonthlyReport.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnViewMonthlyReport.setBackground(Color.WHITE);
		btnViewMonthlyReport.setBounds(10, 183, 192, 39);
		contentPane.add(btnViewMonthlyReport);
		
		desktopReports = new JDesktopPane();
		desktopReports.setBackground(Color.WHITE);
		desktopReports.setBounds(212, 133, 621, 596);
		contentPane.add(desktopReports);
		desktopReports.setLayout(null);
		
		DailyPanel = new JPanel();
		DailyPanel.setBounds(0, 0, 499, 317);
		desktopReports.add(DailyPanel);
		
		JLabel lblNewLabel = new JLabel("Daily-Report");
		lblNewLabel.setBounds(188, 11, 133, 35);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));
		DailyPanel.setVisible(false);
		DailyPanel.setLayout(null);
		DailyPanel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Choose date:");
		lblNewLabel_1.setBounds(24, 67, 110, 28);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		DailyPanel.add(lblNewLabel_1);
		
		dateField = new JTextField();
		dateField.setText("2016-06-01");
		dateField.setBounds(132, 67, 110, 28);
		dateField.setFont(new Font("Tahoma", Font.PLAIN, 14));
		Date dt = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		dateField.setText(sdf.format(dt));
		DailyPanel.add(dateField);
		dateField.setColumns(10);
		
		JButton btnNewButton = new JButton("Create report");
		btnNewButton.setBounds(252, 107, 130, 28);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int dVal;
				
				inputQuery="pullbykey:appointments:app_date,"+dateField.getText();
				inputQuery=inputQuery + ",status,arrived,clinic_num,"+clinicField.getText();
				DailyReportController.ClacDailyDetails(inputQuery);	
					
				DailyReportController.dailyRepEnt.SetDate(dateField.getText());
				DailyReportController.dailyRepEnt.SetClinicNum(Integer.parseInt(clinicField.getText()));
				
				inputQuery="push:daily_report:Date,"+DailyReportController.dailyRepEnt.GetDate();
				inputQuery=inputQuery+",Day_name,"+DailyReportController.dailyRepEnt.GetDayName();
				inputQuery=inputQuery+",Patient_amount,"+DailyReportController.dailyRepEnt.GetPatientsAmount();
				inputQuery=inputQuery+",Waiting_time_avg,"+DailyReportController.dailyRepEnt.GetWaitingTimeAvg();
				inputQuery=inputQuery+",Waiting_time_max,"+DailyReportController.dailyRepEnt.GetWaitingTimeMax();
				inputQuery=inputQuery+",Waiting_time_min,"+DailyReportController.dailyRepEnt.GetWaitingTimeMin();
				inputQuery=inputQuery+",Waiting_time_deviation,"+DailyReportController.dailyRepEnt.GetWwaitingTimeDeviation();
				inputQuery=inputQuery+",Clinic_num,"+DailyReportController.dailyRepEnt.GetClinicNum();
				inputQuery=inputQuery+",waiting_month_0,"+DailyReportController.dailyRepEnt.GetWaiting_month_0();
				inputQuery=inputQuery+",waiting_month_1,"+DailyReportController.dailyRepEnt.GetWaiting_month_1();
				inputQuery=inputQuery+",waiting_month_2,"+DailyReportController.dailyRepEnt.GetWaiting_month_2();
				inputQuery=inputQuery+",waiting_month_3,"+DailyReportController.dailyRepEnt.GetWaiting_month_3();
				DailyReportController.InsertDailyDetailsToDB(inputQuery);
				inputQuery="";
				
				// to block also??
				dVal = DailyReportController.dailyRepEnt.GetPatientsAmount();
				lblPatientAmount.setText(Integer.toString(dVal));
				dVal = DailyReportController.dailyRepEnt.GetWaiting_month_0();
				lbl0.setText(Integer.toString(dVal));
				dVal = DailyReportController.dailyRepEnt.GetWaiting_month_1();
				lbl1.setText(Integer.toString(dVal));
				dVal = DailyReportController.dailyRepEnt.GetWaiting_month_2();
				lbl2.setText(Integer.toString(dVal));
				dVal = DailyReportController.dailyRepEnt.GetWaiting_month_3();
				lbl3.setText(Integer.toString(dVal));
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 15));
		DailyPanel.add(btnNewButton);
		
		JLabel lblPatients = new JLabel("Patients amount:");
		lblPatients.setBounds(24, 156, 133, 19);
		lblPatients.setFont(new Font("Tahoma", Font.PLAIN, 15));
		DailyPanel.add(lblPatients);
		
		lblPatientAmount = new JLabel("0");
		lblPatientAmount.setBounds(168, 156, 78, 19);
		lblPatientAmount.setFont(new Font("Tahoma", Font.PLAIN, 15));
		DailyPanel.add(lblPatientAmount);
		
		label_5 = new JLabel("Waiting time for appointment:");
		label_5.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_5.setBounds(22, 186, 221, 29);
		DailyPanel.add(label_5);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null},
			},
			new String[] {
				"0-30 days", "New column", "New column", "New column", "New column"
			}
		));
		table.setColumnSelectionAllowed(true);
		table.setCellSelectionEnabled(true);
		table.setForeground(Color.MAGENTA);
		table.setSurrendersFocusOnKeystroke(true);
		table.setBounds(419, 229, -209, -84);
		DailyPanel.add(table);
		
		JLabel lblDays = new JLabel("0 - 1");
		lblDays.setHorizontalAlignment(SwingConstants.CENTER);
		lblDays.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblDays.setForeground(Color.BLACK);
		lblDays.setBackground(Color.YELLOW);
		lblDays.setBounds(140, 239, 78, 19);
		DailyPanel.add(lblDays);
		
		JLabel lblDays_1 = new JLabel("1 - 2");
		lblDays_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblDays_1.setForeground(Color.BLACK);
		lblDays_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblDays_1.setBackground(Color.YELLOW);
		lblDays_1.setBounds(228, 239, 78, 19);
		DailyPanel.add(lblDays_1);
		
		lblDays_2 = new JLabel("2 - 3 ");
		lblDays_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblDays_2.setForeground(Color.BLACK);
		lblDays_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblDays_2.setBackground(Color.YELLOW);
		lblDays_2.setBounds(316, 239, 78, 19);
		DailyPanel.add(lblDays_2);
		
		lblDays_3 = new JLabel("3 +");
		lblDays_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblDays_3.setForeground(Color.BLACK);
		lblDays_3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblDays_3.setBackground(Color.YELLOW);
		lblDays_3.setBounds(411, 239, 40, 19);
		DailyPanel.add(lblDays_3);
		
		lblWaitingTime = new JLabel("Patients amount:");
		lblWaitingTime.setForeground(Color.BLACK);
		lblWaitingTime.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblWaitingTime.setBackground(Color.YELLOW);
		lblWaitingTime.setBounds(22, 269, 118, 19);
		DailyPanel.add(lblWaitingTime);
		
		lbl0 = new JLabel("0");
		lbl0.setHorizontalAlignment(SwingConstants.CENTER);
		lbl0.setForeground(Color.BLACK);
		lbl0.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lbl0.setBackground(Color.YELLOW);
		lbl0.setBounds(140, 269, 66, 19);
		DailyPanel.add(lbl0);
		
		lbl1 = new JLabel("0");
		lbl1.setHorizontalAlignment(SwingConstants.CENTER);
		lbl1.setForeground(Color.BLACK);
		lbl1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lbl1.setBackground(Color.YELLOW);
		lbl1.setBounds(224, 269, 66, 19);
		DailyPanel.add(lbl1);
		
		lbl2 = new JLabel("0");
		lbl2.setHorizontalAlignment(SwingConstants.CENTER);
		lbl2.setForeground(Color.BLACK);
		lbl2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lbl2.setBackground(Color.YELLOW);
		lbl2.setBounds(316, 269, 66, 19);
		DailyPanel.add(lbl2);
		
		lbl3 = new JLabel("0");
		lbl3.setHorizontalAlignment(SwingConstants.CENTER);
		lbl3.setForeground(Color.BLACK);
		lbl3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lbl3.setBackground(Color.YELLOW);
		lbl3.setBounds(403, 269, 46, 19);
		DailyPanel.add(lbl3);
		
		lblMonth = new JLabel("Months:");
		lblMonth.setForeground(Color.BLACK);
		lblMonth.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblMonth.setBackground(Color.YELLOW);
		lblMonth.setBounds(22, 239, 98, 19);
		DailyPanel.add(lblMonth);
		
		JLabel lblClinicName = new JLabel("Clinic num:");
		lblClinicName.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblClinicName.setBounds(24, 106, 110, 28);
		DailyPanel.add(lblClinicName);
		
		clinicField = new JTextField();
		clinicField.setText("22");
		clinicField.setFont(new Font("Tahoma", Font.PLAIN, 14));
		clinicField.setColumns(10);
		clinicField.setBounds(132, 106, 110, 28);
		DailyPanel.add(clinicField);
		
		JButton btnDailyReport = new JButton("Daily Report");
		btnDailyReport.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnDailyReport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("Daily Report");
				DailyPanel.setVisible(true);

			}
		});
		btnDailyReport.setBounds(10, 233, 192, 39);
		contentPane.add(btnDailyReport);
	}
	
	
	//display the type of monthly report
	private void createEvents1() {
		btnViewMonthlyReport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				DailyPanel.setVisible(false);
				if (WeekRep != null )
					WeekRep.dispose();/// close week report if open
				if (Rep == null || Rep.isClosed())
				Rep = new TypeOfMonthlyReports();  ////  �� ����� ������ �� ������ ����� ������ 
				desktopReports.add(Rep);/// ���� �� ���� ����
				Rep.show(); // ������ �����
			}
		});
	}

	//for weekly report
	private void createEvents2() {
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DailyPanel.setVisible(false);
				if (Rep != null)
					Rep.dispose();/// close month report if open
				if (WeekRep == null || WeekRep.isClosed())
					WeekRep = new WeeklyReport();  ////  �� ����� ������ �� ������ ����� ������ 
					desktopReports.add(WeekRep);/// ���� �� ���� ����
					WeekRep.show(); // ������ �����
					
					//close whene pressed back
					WeekRep.backButton.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							WeekRep.dispose();
							 //
						}
					});	
			}
		});
		
	}
}
