package javagui.views;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.border.TitledBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JScrollPane;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import javax.swing.UIManager;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javagui.views.*;
import controllers.AppointmentControllers;

import javax.swing.JTextArea;

public class RecordAppointment extends JInternalFrame {
	public JTextField textField_1;
	public JTextField appId;
	public JScrollPane scrollPane;
	public  JCheckBox chckbxArrived;
	public  String  inputQuery;
	public  JButton button;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RecordAppointment frame = new RecordAppointment();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RecordAppointment() {
		getContentPane().setBackground(Color.WHITE);
		setBounds(0, 0, 505, 477);
		getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 489, 447);
		getContentPane().add(panel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		
		JLabel lblSummery = new JLabel("Summery:");
		lblSummery.setBounds(21, 184, 48, 14);
		
		JLabel lblAppointmentid = new JLabel("Appointment ID:");
		lblAppointmentid.setBounds(21, 16, 108, 14);
		
		JLabel lblAppointmenttime = new JLabel("Appointment time:");
		lblAppointmenttime.setBounds(21, 75, 108, 14);
		
		textField_1 = new JTextField();
		textField_1.setBounds(139, 72, 288, 20);
		textField_1.setColumns(10);
		
		appId = new JTextField();
		appId.setBounds(139, 13, 288, 20);
		appId.setColumns(10);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(139, 184, 319, 147);
		
		JCheckBox chckbxArrived = new JCheckBox("patient arrived");
		chckbxArrived.setBounds(139, 127, 97, 23);
		JPanel panel_3 = new JPanel();
		
		button = new JButton("Accept");

		
		JButton button_1 = new JButton("Clear");

		GroupLayout gl_panel_3 = new GroupLayout(panel_3);
		gl_panel_3.setHorizontalGroup(
			gl_panel_3.createParallelGroup(Alignment.LEADING)
				.addGap(0, 452, Short.MAX_VALUE)
				.addGroup(gl_panel_3.createSequentialGroup()
					.addGap(123)
					.addComponent(button)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(button_1, GroupLayout.PREFERRED_SIZE, 87, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(171, Short.MAX_VALUE))
		);
		gl_panel_3.setVerticalGroup(
			gl_panel_3.createParallelGroup(Alignment.TRAILING)
				.addGap(0, 54, Short.MAX_VALUE)
				.addGroup(gl_panel_3.createSequentialGroup()
					.addContainerGap(20, Short.MAX_VALUE)
					.addGroup(gl_panel_3.createParallelGroup(Alignment.BASELINE)
						.addComponent(button_1)
						.addComponent(button))
					.addContainerGap())
		);
		panel_3.setLayout(gl_panel_3);
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addComponent(panel_1, GroupLayout.DEFAULT_SIZE, 489, Short.MAX_VALUE)
				.addGroup(Alignment.TRAILING, gl_panel.createSequentialGroup()
					.addContainerGap()
					.addComponent(panel_3, GroupLayout.DEFAULT_SIZE, 469, Short.MAX_VALUE)
					.addGap(10))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_panel.createSequentialGroup()
					.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, 355, Short.MAX_VALUE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(panel_3, GroupLayout.PREFERRED_SIZE, 70, GroupLayout.PREFERRED_SIZE)
					.addContainerGap())
		);
		panel_1.setLayout(null);
		panel_1.add(lblAppointmenttime);
		panel_1.add(lblAppointmentid);
		panel_1.add(lblSummery);
		panel_1.add(chckbxArrived);
		panel_1.add(textField_1);
		panel_1.add(appId);
		panel_1.add(scrollPane);
		
		JTextArea textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
		panel.setLayout(gl_panel);

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				inputQuery="update:appointments:appointment_num,"+GeneralDoctor.app.getAppointment_num()+",status,"+ (chckbxArrived.isSelected()?"arrived":"not");
				System.out.println("\nze ze "+inputQuery);
				AppointmentControllers.updateArrived(inputQuery);
				inputQuery="";
				
				inputQuery="update:appointments:appointment_num,"+GeneralDoctor.app.getAppointment_num()+",results,"+ textArea.getText();
				System.out.println("\nze ze "+inputQuery);
				AppointmentControllers.updateArrived(inputQuery);
				inputQuery="";
				GeneralDoctor.tabbedPane.setEnabledAt(1, true);
				GeneralDoctor.tabbedPane.setSelectedIndex(1);}});
		
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				chckbxArrived.setSelected(false);
				textArea.setText("");
			}
			
		});
	}
}
