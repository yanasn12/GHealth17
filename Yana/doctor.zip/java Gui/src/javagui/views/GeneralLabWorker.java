package javagui.views;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.ImageIcon;
import java.awt.Toolkit;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JDesktopPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTextField;

public class GeneralLabWorker extends JFrame {

	private JPanel contentPane;
	private JDesktopPane desktopReports;
	private JButton btnInsetLabReferral;
	private referralList RefList;
//	private tttt weekRep;
	private JButton btnReferralList;
	private JTextField textField;
	private JLabel lblPatientId;
	private JButton btnApply;
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GeneralLabWorker frame = new GeneralLabWorker();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GeneralLabWorker() {
		initComponent(); //// ����� �� INIT ��� �� �� �� ������ ��������
		createEvent1();/// ����� ������- ���� ����
		//createEvent2();
	}
	///////// init component of desktop reports
	private void initComponent() {
		//	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	//	setBounds(0, 0, 810, 775);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(GeneralLabWorker.class.getResource("/javagui/resources/GHealthlogo.png")));
		label.setBounds(113, 25, 242, 68);
		contentPane.add(label);
		
		btnReferralList = new JButton("Referral list");
		btnReferralList.setEnabled(false);
	
		btnReferralList.setIcon(new ImageIcon(GeneralLabWorker.class.getResource("/javagui/resources/img16x16/reports.png")));
		btnReferralList.setHorizontalAlignment(SwingConstants.LEFT);
		btnReferralList.setForeground(Color.BLUE);
		btnReferralList.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnReferralList.setBackground(Color.BLUE);
		btnReferralList.setBounds(10, 130, 192, 39);
		contentPane.add(btnReferralList);
		
		btnInsetLabReferral = new JButton("Inset lab referral");
		btnInsetLabReferral.setEnabled(false);
		
		btnInsetLabReferral.setIcon(new ImageIcon(GeneralLabWorker.class.getResource("/javagui/resources/img16x16/reports.png")));
		btnInsetLabReferral.setHorizontalAlignment(SwingConstants.LEFT);
		btnInsetLabReferral.setForeground(Color.BLUE);
		btnInsetLabReferral.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnInsetLabReferral.setBackground(Color.BLUE);
		btnInsetLabReferral.setBounds(10, 183, 192, 39);
		contentPane.add(btnInsetLabReferral);
		
		desktopReports = new JDesktopPane();
		desktopReports.setBackground(Color.WHITE);
		desktopReports.setBounds(212, 133, 548, 589);
		contentPane.add(desktopReports);
		desktopReports.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(399, 100, 86, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		lblPatientId = new JLabel("Patient ID:");
		lblPatientId.setBounds(330, 103, 59, 14);
		contentPane.add(lblPatientId);
		
		btnApply = new JButton("apply");
		btnApply.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnReferralList.setEnabled(true);
			}
		});
		btnApply.setBounds(495, 99, 76, 23);
		contentPane.add(btnApply);
	}
	
	//display the type of monthly report
	private void createEvent1() {
		btnReferralList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (RefList == null || RefList.isClosed())/////////
					RefList = new referralList();  ////  �� ����� ������ �� ������ ����� ������ 
				desktopReports.add(RefList);/// ���� �� ���� ����
				RefList.show(); // ������ �����
			}
		});
		
				
		
	}

	/// display weekly report
	/*private void createEvent2() {
	button.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			
			weekRep = new WeeklyReport ();
			desktopReports.add(weekRep);
			weekRep.e
			setContentPane(weekRep);/// ���� �� ���� ����	
			
			//////////////////////////////////////////////////////////////////////////////
		}
	});
}
}*/
}
