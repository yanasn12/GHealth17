package javagui.views;

import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.JTable;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import controllers.Dispatcher;
import Entitys.patient;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.JList;

public class Dispather_date_and_time extends JPanel {
private JPanel panel;
public static JComboBox comboBox=null ;
public boolean flag=false;
public boolean flag2=false;
public static String [] box;
public static String [] box2;
private JButton btnMakeIt;

private String getDate;
private String getplaceAndTime;
/**
	 * Create the panel.
	 */
public Dispather_date_and_time() {
	setBorder(null);
		setBackground(Color.WHITE);
		setLayout(null);


		into2();
	}

public JPanel into2(){
		
	if(panel==null)
		panel= new JPanel();
		JLabel lblDate = new JLabel("Date:");
		//panel.setBounds(0, y, width, height);
		lblDate.setBounds(55, 87, 46, 14);
		add(lblDate);
		

			if(flag)
			{
			Dispather_Gui_main.datasave.reloadTime();
			comboBox = new JComboBox(box);
			comboBox.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					getDate = comboBox.getSelectedItem().toString();
					Dispather_Gui_main.datasave.reloadByDate(getDate);
					
					Dispather_date_and_time.box2=Dispather_Gui_main.datasave.PlaceAndTimeToArray;
					flag2=true;
					
					into2();
				}
			});
				comboBox.setBounds(123, 84, 127, 20);
					add(comboBox);
			}

			Dispather_Doctor.btnSelect.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Dispatcher.get_Date_Place_Time(Dispather_Gui_main.datasave.getDoctor_info(), Dispather_Client_info_Gui.WorkUser);
					Dispather_Gui_main.datasave.reloadTime();
					Dispather_date_and_time.box =Dispather_Gui_main.datasave.DateToArray;
					flag=true;
					into2();
					
				}});
			if(flag2)
			{
				Dispather_Gui_main.datasave.reloadTime();
				JLabel lblPlaceAndTime = new JLabel("Place And Time");
				lblPlaceAndTime.setBounds(150, 172, 102, 14);
				add(lblPlaceAndTime);
				
				JComboBox comboBox_1 = new JComboBox(box2);
				comboBox_1.setBounds(252, 169, 200, 20);
				comboBox_1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						getplaceAndTime = comboBox_1.getSelectedItem().toString();
							Dispather_Gui_main.datasave.reloadByDate(getplaceAndTime);
							
						
						Dispather_date_and_time.box2=Dispather_Gui_main.datasave.PlaceAndTimeToArray;
						flag2=true;
						into2();
					}
				});
				add(comboBox_1);
					
				JButton btnMakeIt = new JButton("Make It");
				btnMakeIt.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
					/*	if(Dispather_Gui_main.datasave.MakeAppointment(getDate,getplaceAndTime)==true)
						{
							//return Ok
						}
						else
						{
							//errorMassage
						}*/
					}
				});
				btnMakeIt.setBounds(150, 259, 89, 23);
				add(btnMakeIt);

			}

		return panel;
}
}