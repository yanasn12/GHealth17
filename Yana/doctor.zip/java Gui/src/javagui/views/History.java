package javagui.views;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JTextArea;

public class History extends JInternalFrame {
	public JTextField textField;
	public JTextField textField_1;
	public JTextField textField_2;
	public JTextField textField_3;
	public JTextField textField_4;
	public JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					History frame = new History();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public History() {
		setBounds(100, 100, 556, 554);
		getContentPane().setLayout(null);
		
		JLabel lblHistory = new JLabel("History:");
		lblHistory.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblHistory.setBounds(10, 11, 82, 33);
		getContentPane().add(lblHistory);
		
		JLabel lblAppointmentnum = new JLabel("appointment_num");
		lblAppointmentnum.setBounds(10, 57, 111, 14);
		getContentPane().add(lblAppointmentnum);
		
		JLabel lblAppointmentDate = new JLabel("appointment date:");
		lblAppointmentDate.setBounds(10, 91, 111, 14);
		getContentPane().add(lblAppointmentDate);
		
		JLabel lblHour = new JLabel("hour:");
		lblHour.setBounds(270, 91, 111, 14);
		getContentPane().add(lblHour);
		
		JLabel lblCallDate = new JLabel("call date:");
		lblCallDate.setBounds(10, 129, 111, 14);
		getContentPane().add(lblCallDate);
		
		JLabel lblStatus = new JLabel("status:");
		lblStatus.setBounds(10, 166, 111, 14);
		getContentPane().add(lblStatus);
		
		JLabel lblResults = new JLabel("results:");
		lblResults.setBounds(10, 198, 111, 14);
		getContentPane().add(lblResults);
		
		textField = new JTextField();
		textField.setBounds(117, 54, 111, 20);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(117, 88, 111, 20);
		getContentPane().add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(117, 126, 111, 20);
		getContentPane().add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(117, 163, 111, 20);
		getContentPane().add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(117, 195, 111, 20);
		getContentPane().add(textField_4);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(303, 88, 111, 20);
		getContentPane().add(textField_5);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(283, 31, 131, 20);
		getContentPane().add(comboBox);
		
		JLabel lblAppointments = new JLabel("appointments:");
		lblAppointments.setBounds(158, 30, 82, 14);
		getContentPane().add(lblAppointments);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setBounds(283, 247, 131, 20);
		getContentPane().add(comboBox_1);
		
		JLabel lblTestLabs = new JLabel("test labs:");
		lblTestLabs.setBounds(182, 250, 46, 14);
		getContentPane().add(lblTestLabs);
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(146, 273, 168, 20);
		getContentPane().add(textField_6);
		
		JLabel label = new JLabel("Test ID:");
		label.setBounds(10, 276, 160, 14);
		getContentPane().add(label);
		
		JLabel label_1 = new JLabel("Test Type:");
		label_1.setBounds(10, 307, 160, 14);
		getContentPane().add(label_1);
		
		textField_7 = new JTextField();
		textField_7.setColumns(10);
		textField_7.setBounds(146, 304, 168, 20);
		getContentPane().add(textField_7);
		
		textField_8 = new JTextField();
		textField_8.setColumns(10);
		textField_8.setBounds(146, 335, 168, 20);
		getContentPane().add(textField_8);
		
		JLabel label_2 = new JLabel("Opening Date:");
		label_2.setBounds(10, 338, 160, 14);
		getContentPane().add(label_2);
		
		JLabel label_3 = new JLabel("Closing Date:");
		label_3.setBounds(10, 369, 160, 14);
		getContentPane().add(label_3);
		
		textField_9 = new JTextField();
		textField_9.setColumns(10);
		textField_9.setBounds(146, 366, 168, 20);
		getContentPane().add(textField_9);
		
		textField_10 = new JTextField();
		textField_10.setColumns(10);
		textField_10.setBounds(146, 395, 168, 20);
		getContentPane().add(textField_10);
		
		JLabel label_4 = new JLabel("Urgency:");
		label_4.setBounds(10, 398, 160, 14);
		getContentPane().add(label_4);
		
		JLabel label_5 = new JLabel("notes:");
		label_5.setBounds(10, 426, 160, 14);
		getContentPane().add(label_5);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(146, 427, 198, 41);
		getContentPane().add(textArea);

	}
}
