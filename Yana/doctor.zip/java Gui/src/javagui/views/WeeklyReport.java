package javagui.views;

import Entitys.Weekly_Report_Entity;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import javax.swing.UIManager;

import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.JTextField;

import java.awt.Font;

import javax.swing.JButton;
import javax.swing.ImageIcon;

import controllers.ClinicWeeklyReport;
import controllers.GuiLogin;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class WeeklyReport extends JInternalFrame {
	public Weekly_Report_Entity weekRep= new Weekly_Report_Entity();
	public JButton backButton;
	private JButton btnSearch;
	private String inputQuery="";
	private JLabel lblAvg;
	private JComboBox cbDay, cbMonth, cbYear;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					WeeklyReport frame = new WeeklyReport();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	public WeeklyReport() {
		setBounds(0, 0, 462, 519);
		getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Weekly Report", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel.setBounds(10, 11, 427, 467);
		getContentPane().add(panel);
		
		JLabel label = new JLabel("Date : ");
		label.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label.setBounds(48, 29, 52, 22);
		panel.add(label);
			
		btnSearch = new JButton("Search");
		btnSearch.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				float fVal;
				int dVal;
				String date="", monthDate="", yearDate;
				yearDate = "2016";
				
				int index = cbMonth.getSelectedIndex()+1;
				if(index < 10)
					monthDate = "0"+Integer.toString(index);
				else
					monthDate = Integer.toString(index);
				
				index = cbDay.getSelectedIndex()+1;
				if(index < 10)
					date = "0"+Integer.toString(index);
				else
					date = Integer.toString(index);
				date = yearDate+"-"+monthDate+"-"+date;
				
				inputQuery="pullbykey:weekly_report:"+ "start_week_date," + date;
				ClinicWeeklyReport.ShowByDate(inputQuery);
				inputQuery="";
				
				fVal = ClinicWeeklyReport.week_rep.getAvgWaitingTimeForAppointment();
				lblAvg.setText(Float.toString(fVal));
			}
		});
		btnSearch.setBounds(321, 75, 75, 23);
		panel.add(btnSearch);
		
		
		JLabel label_1 = new JLabel("Weekly report ");
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		label_1.setBounds(134, 126, 144, 34);
		panel.add(label_1);
		
		JLabel lblPatientsAmount = new JLabel("Patients amount:");
		lblPatientsAmount.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblPatientsAmount.setBounds(10, 177, 127, 14);
		panel.add(lblPatientsAmount);
		
		JLabel label_4 = new JLabel("Waiting time for appointment:");
		label_4.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_4.setBounds(10, 205, 194, 22);
		panel.add(label_4);
		
		backButton = new JButton("Back");
	
	
		backButton.setIcon(new ImageIcon(WeeklyReport.class.getResource("/javagui/resources/Back.png")));
		backButton.setBounds(298, 415, 108, 41);
		panel.add(backButton);
		
		JLabel label_9 = new JLabel("- Maximum value:");
		label_9.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_9.setBounds(77, 270, 145, 23);
		panel.add(label_9);
		
		JLabel label_10 = new JLabel("- Average value:");
		label_10.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_10.setBounds(77, 230, 145, 20);
		panel.add(label_10);
		
		JLabel label_11 = new JLabel("- Minimum value:");
		label_11.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_11.setBounds(77, 249, 145, 23);
		panel.add(label_11);
		
		JLabel lblStandardDeviation = new JLabel("- Standard deviation:");
		lblStandardDeviation.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblStandardDeviation.setBounds(78, 291, 144, 20);
		panel.add(lblStandardDeviation);
		
		JLabel label_2 = new JLabel("Patients amount:");
		label_2.setForeground(Color.BLACK);
		label_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_2.setBackground(Color.YELLOW);
		label_2.setBounds(10, 377, 118, 19);
		panel.add(label_2);
		
		JLabel label_3 = new JLabel("0 - 1");
		label_3.setHorizontalAlignment(SwingConstants.CENTER);
		label_3.setForeground(Color.BLACK);
		label_3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_3.setBackground(Color.YELLOW);
		label_3.setBounds(134, 347, 60, 19);
		panel.add(label_3);
		
		JLabel lbl0month = new JLabel("0");
		lbl0month.setHorizontalAlignment(SwingConstants.CENTER);
		lbl0month.setForeground(Color.BLACK);
		lbl0month.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lbl0month.setBackground(Color.YELLOW);
		lbl0month.setBounds(128, 377, 66, 19);
		panel.add(lbl0month);
		
		JLabel label_6 = new JLabel("1 - 2");
		label_6.setHorizontalAlignment(SwingConstants.CENTER);
		label_6.setForeground(Color.BLACK);
		label_6.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_6.setBackground(Color.YELLOW);
		label_6.setBounds(204, 347, 60, 19);
		panel.add(label_6);
		
		JLabel lbl1month = new JLabel("0");
		lbl1month.setHorizontalAlignment(SwingConstants.CENTER);
		lbl1month.setForeground(Color.BLACK);
		lbl1month.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lbl1month.setBackground(Color.YELLOW);
		lbl1month.setBounds(204, 377, 66, 19);
		panel.add(lbl1month);
		
		JLabel label_8 = new JLabel("2 - 3");
		label_8.setHorizontalAlignment(SwingConstants.CENTER);
		label_8.setForeground(Color.BLACK);
		label_8.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_8.setBackground(Color.YELLOW);
		label_8.setBounds(274, 347, 60, 19);
		panel.add(label_8);
		
		JLabel lbl2month = new JLabel("0");
		lbl2month.setHorizontalAlignment(SwingConstants.CENTER);
		lbl2month.setForeground(Color.BLACK);
		lbl2month.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lbl2month.setBackground(Color.YELLOW);
		lbl2month.setBounds(268, 377, 66, 19);
		panel.add(lbl2month);
		
		JLabel label_14 = new JLabel("3 + ");
		label_14.setHorizontalAlignment(SwingConstants.CENTER);
		label_14.setForeground(Color.BLACK);
		label_14.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_14.setBackground(Color.YELLOW);
		label_14.setBounds(344, 347, 52, 19);
		panel.add(label_14);
		
		JLabel lbl3month = new JLabel("0");
		lbl3month.setHorizontalAlignment(SwingConstants.CENTER);
		lbl3month.setForeground(Color.BLACK);
		lbl3month.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lbl3month.setBackground(Color.YELLOW);
		lbl3month.setBounds(344, 377, 52, 19);
		panel.add(lbl3month);
		
		JLabel lblMonths = new JLabel("Months:");
		lblMonths.setForeground(Color.BLACK);
		lblMonths.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblMonths.setBackground(Color.YELLOW);
		lblMonths.setBounds(66, 347, 60, 19);
		panel.add(lblMonths);
		
		JLabel lblPatientAmount = new JLabel("0");
		lblPatientAmount.setHorizontalAlignment(SwingConstants.CENTER);
		lblPatientAmount.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblPatientAmount.setBounds(223, 179, 46, 14);
		panel.add(lblPatientAmount);
		
		lblAvg = new JLabel("0");
		lblAvg.setHorizontalAlignment(SwingConstants.CENTER);
		lblAvg.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblAvg.setBounds(223, 235, 46, 14);
		panel.add(lblAvg);
		
		JLabel lblMin = new JLabel("0");
		lblMin.setHorizontalAlignment(SwingConstants.CENTER);
		lblMin.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblMin.setBounds(223, 255, 46, 14);
		panel.add(lblMin);
		
		JLabel lblMax = new JLabel("0");
		lblMax.setHorizontalAlignment(SwingConstants.CENTER);
		lblMax.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblMax.setBounds(223, 276, 46, 14);
		panel.add(lblMax);
		
		JLabel lblDev = new JLabel("0");
		lblDev.setHorizontalAlignment(SwingConstants.CENTER);
		lblDev.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblDev.setBounds(223, 296, 46, 14);
		panel.add(lblDev);
		
		cbMonth = new JComboBox();
		cbMonth.setFont(new Font("Tahoma", Font.PLAIN, 15));
		cbMonth.setModel(new DefaultComboBoxModel(new String[] {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"}));
		cbMonth.setBounds(187, 28, 108, 24);
		panel.add(cbMonth);
		
		cbDay = new JComboBox();
		cbDay.setToolTipText("");
		cbDay.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"}));
		cbDay.setFont(new Font("Tahoma", Font.PLAIN, 15));
		cbDay.setBounds(110, 29, 52, 23);
		panel.add(cbDay);
		
		cbYear = new JComboBox();
		cbYear.setModel(new DefaultComboBoxModel(new String[] {"2016"}));
		cbYear.setFont(new Font("Tahoma", Font.PLAIN, 15));
		cbYear.setBounds(321, 29, 75, 23);
		panel.add(cbYear);
		
		JLabel label_5 = new JLabel("-");
		label_5.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_5.setHorizontalAlignment(SwingConstants.CENTER);
		label_5.setBounds(158, 30, 36, 20);
		panel.add(label_5);
		
		JLabel label_7 = new JLabel("-");
		label_7.setHorizontalAlignment(SwingConstants.CENTER);
		label_7.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_7.setBounds(292, 30, 31, 20);
		panel.add(label_7);
		
		JLabel lblClinicName = new JLabel("Clinic name:");
		lblClinicName.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblClinicName.setBounds(10, 75, 100, 22);
		panel.add(lblClinicName);
		
		JComboBox cbClinicName = CreateClinicComboBox();
		panel.add(cbClinicName);
	}
	
	private JComboBox CreateClinicComboBox(){
		JComboBox cbClinicName = new JComboBox();
		cbClinicName.setModel(new DefaultComboBoxModel(new String[] {"name"}));
		cbClinicName.setToolTipText("Name of clinic");				// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		cbClinicName.setFont(new Font("Tahoma", Font.PLAIN, 15));
		cbClinicName.setBounds(107, 74, 194, 24);
		
//		inputQuery="pullbykey:clinics: start_week_date," + date;
//		ClinicWeeklyReport.ShowByDate(inputQuery);
//		inputQuery="";
		
		
		return cbClinicName;
	}
}
