package javagui.views;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.SystemColor;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Color;

import controllers.Doctor;
import Entitys.patient;
import Entitys.Appointment;

import javax.swing.JLabel;
import javax.swing.JButton;
//import javagui.views.RecordAppointment;


import java.awt.Font;

import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JDesktopPane;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JComboBox;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.beans.PropertyVetoException;

import javax.swing.JTabbedPane;

import controllers.DailyReportController;
import controllers.Dispatcher;
import controllers.AppointmentControllers;

import javax.swing.JCheckBox;

public class GeneralDoctor extends JFrame {

	private JPanel contentPane=null;
	private JTextField textField;
	private String pname="";
	private JTextField textField_1;
	private JButton btnViewDetails_1;
	private JPanel panel_1;
	private RecordAppointment recordAppointment =new RecordAppointment();
	private RequestFile window2 = new RequestFile();
	private ReferralToLabratory window3 = new ReferralToLabratory();
	private History window5=new History();
	public static patient WorkUser = new patient();
	public static Appointment app = new Appointment();
	private JTextField textField_2;
	public static JTabbedPane tabbedPane;

	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GeneralDoctor frame = new GeneralDoctor();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */


	public GeneralDoctor() {	
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBackground(Color.WHITE);
		this.setTitle("Expert");
		setBounds(100, 100, 1000, 1000);
		this.setContentPane(into());
		
}
	private JPanel into()
	{
		if(contentPane==null){
			contentPane =new JPanel();
			contentPane.setBackground(SystemColor.window);
			contentPane.setBackground(SystemColor.WHITE);
		contentPane.setBorder(new EmptyBorder(6 , 6, 6, 6));
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("");
		label.setBounds(86, 10, 192, 68);
		label.setIcon(new ImageIcon(GeneralDoctor.class.getResource("/javagui/resources/GHealthlogo.png")));
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("Patient ID:");
		label_1.setBounds(35, 89, 95, 14);
		contentPane.add(label_1);
		
		textField = new JTextField();
		textField.setBounds(96, 89, 86, 20);
		textField.setColumns(10);
		contentPane.add(textField);
		
		JButton button_2 = new JButton("apply");
		button_2.setBounds(192, 89, 83, 23);
		contentPane.add(button_2);
		
		JButton btnCreateReferral = new JButton("Referral to expert");
		btnCreateReferral.setBounds(24, 311, 149, 23);

		btnCreateReferral.setEnabled(false);
		btnCreateReferral.setHorizontalAlignment(SwingConstants.LEFT);
		btnCreateReferral.setForeground(Color.BLUE);
		btnCreateReferral.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnCreateReferral.setBackground(Color.WHITE);
		contentPane.add(btnCreateReferral);
		
		JButton btnViewDetails_1 = new JButton("Record appointment");
		btnViewDetails_1.setBounds(24, 177, 149, 23);
		
				btnViewDetails_1.setEnabled(false);
				btnViewDetails_1.setHorizontalAlignment(SwingConstants.LEFT);
				btnViewDetails_1.setForeground(Color.BLUE);
				btnViewDetails_1.setFont(new Font("Tahoma", Font.BOLD, 11));
				btnViewDetails_1.setBackground(Color.WHITE);
				contentPane.add(btnViewDetails_1);
				

		
		JButton btnRequestFile = new JButton("Request file");
		btnRequestFile.setBounds(24, 269, 149, 23);

		
				btnRequestFile.setEnabled(false);
				btnRequestFile.setHorizontalAlignment(SwingConstants.LEFT);
				btnRequestFile.setForeground(Color.BLUE);
				btnRequestFile.setFont(new Font("Tahoma", Font.BOLD, 11));
				btnRequestFile.setBackground(Color.WHITE);
				contentPane.add(btnRequestFile);
		
		JButton btnLabratory = new JButton("Referral to labratory");
		btnLabratory.setBounds(24, 226, 149, 23);


		btnLabratory.setEnabled(false);
		btnLabratory.setHorizontalAlignment(SwingConstants.LEFT);
		btnLabratory.setForeground(Color.BLUE);
		btnLabratory.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnLabratory.setBackground(Color.WHITE);
		contentPane.add(btnLabratory);
		
		JButton btnViewHistory = new JButton("View History");
		btnViewHistory.setBounds(24, 355, 149, 23);
		btnViewHistory.setHorizontalAlignment(SwingConstants.LEFT);
		btnViewHistory.setForeground(Color.BLUE);
		btnViewHistory.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnViewHistory.setEnabled(false);
		btnViewHistory.setBackground(Color.WHITE);
		contentPane.add(btnViewHistory);
		
		JLabel lblPatientDetails = new JLabel("patient details:" + pname);
		lblPatientDetails.setBounds(35, 130, 114, 14);
		
		contentPane.add(lblPatientDetails);
		
		textField_1 = new JTextField();
		textField_1.setBounds(159, 127, 585, 20);
		textField_1.setEnabled(false);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(257, 177, 506, 530);
		contentPane.add(tabbedPane);
		recordAppointment.appId.setEditable(false);
		recordAppointment.getContentPane().setLayout(null);
		recordAppointment.textField_1.setBounds(139, 67, 258, 30);
		recordAppointment.appId.setBounds(139, 11, 258, 30);
		recordAppointment.scrollPane.setBounds(139, 184, 319, 147);
		
		textField_2 = new JTextField();
		textField_2.setBounds(139, 54, 209, 20);
		recordAppointment.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		tabbedPane.addTab("Record appointment", null,recordAppointment,null);
		tabbedPane.addTab("Request File", null,window2,null);
		window3.setEnabled(false);
		tabbedPane.addTab("Referral to lab", null,window3,null);
		tabbedPane.addTab("history", null,window5,null);
		window5.getContentPane().setLayout(null);;
	//	GeneralDoctor.tabbedPane.setEnabledAt(2, false);
	//	GeneralDoctor.tabbedPane.setEnabledAt(3, false);
	//	GeneralDoctor.tabbedPane.setEnabledAt(1, false);
		
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				button_2.setVisible(true);
				textField.setEnabled(true);
				btnViewDetails_1.setEnabled(true);
				btnRequestFile.setEnabled(true);
				btnCreateReferral.setEnabled(true);
				btnLabratory.setEnabled(true);
				
				
				if(Doctor.iDInfo(textField.getText(),WorkUser)==true)
				{
					textField_1.setText("name: " +WorkUser.getFirst_name() + " " + WorkUser.getLast_name()+ "  "+" BirthDate: "+" "+WorkUser.getBirth_date()+" Address: " + WorkUser.getAddress()+" Phone number: " + WorkUser.getPhone() );
					if(AppointmentControllers.CurrentAppointment(app,WorkUser,textField.getText())==true )
					{
						if (WorkUser.getPatient_num()==(app.getPatientNum())){

						recordAppointment.appId.setText(Integer.toString(app.getAppointment_num()));
						recordAppointment.textField_1.setText(app.getApp_date()+" at "+ app.getApp_hour()+ "  o'clock" );}
						else JOptionPane.showMessageDialog(null,"patient doesnt have an appointment now", "Doctor",JOptionPane.PLAIN_MESSAGE);
					}
					else JOptionPane.showMessageDialog(null,"patient doesnt have an appointment now", "Doctor",JOptionPane.PLAIN_MESSAGE);
				}
				
				else JOptionPane.showMessageDialog(null,"patient not exist", "Doctor",JOptionPane.PLAIN_MESSAGE);
				
			}
		});


		
		btnViewDetails_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}});
		
		btnLabratory.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
		}});
		
		btnRequestFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

			}});
	

	}

	return contentPane;
	}	
}
