package javagui.views;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.plaf.basic.DefaultMenuLayout;

import controllers.Dispatcher;
import Entitys.patient;
import net.miginfocom.swing.MigLayout;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.ActionEvent;
import javax.swing.JList;

public class Dispather_Doctor extends JPanel {
	public static JButton btnSelect;
	private JComboBox comboBox_1;
	public String [] list;
	private boolean ShowComboBox=false;
	public static JButton btnShowListOf;
	/**
	 * Create the panel.
	 */

	public Dispather_Doctor() {
		
		setLayout(new MigLayout("", "[][][][][][]", "[][][][][][][][][][][][]"));
		setBackground(Color.WHITE);
		
		btnSelect = new JButton("Select");

	
		into();
	}

private void into()
{

				if(ShowComboBox)
				{							
					
					comboBox_1 = new JComboBox(patient.DoctorToArray);
					btnSelect.setVisible(ShowComboBox);
					btnShowListOf.setVisible(false);
					comboBox_1.addItemListener(new ItemListener() {
						public void itemStateChanged(ItemEvent arg0) {
							Dispather_Gui_main.datasave.setDoctor_info(comboBox_1.getSelectedItem().toString());
						
						}
					});				
					add(comboBox_1, "cell 2 1,growx");
				}
				
				
				btnShowListOf = new JButton("Show List Of Doctors");
				btnShowListOf.setVisible(!ShowComboBox);
				btnShowListOf.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						 Dispatcher.listOfExperts(Dispather_Client_info_Gui.WorkUser.getReferral_num(), Dispather_Client_info_Gui.WorkUser);
						 Dispather_Gui_main.datasave.reload();
						 ShowComboBox=true;
						 into();
						

						
					}
				});
				add(btnShowListOf, "cell 1 0");
				
				btnSelect.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						Dispatcher.get_Date_Place_Time(Dispather_Gui_main.datasave.getDoctor_info(), Dispather_Client_info_Gui.WorkUser);
						Dispather_Gui_main.datasave.reloadTime();
						Dispather_date_and_time.box =Dispather_Gui_main.datasave.DateToArray;
					}
				});
				
				
				
				
				add(btnSelect, "cell 5 11,alignx right");
				

	}

}