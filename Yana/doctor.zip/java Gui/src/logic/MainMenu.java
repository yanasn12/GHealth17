package logic;

import java.awt.Toolkit;
import javax.swing.JFrame;
import javagui.views.*;

public class MainMenu {

	public static void main(String args[])
	{
		Login mainFrame = new Login();
		mainFrame.setTitle("Login");
		mainFrame.setIconImage(Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/javagui/resources/report-icon.jpg")));
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mainFrame.setSize(1000,1000);
		mainFrame.setVisible(true);
	}
}
