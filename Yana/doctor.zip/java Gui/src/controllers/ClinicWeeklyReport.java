package controllers;

import java.util.ArrayList;

import javax.swing.JOptionPane;

import Entitys.Weekly_Report_Entity;

public class ClinicWeeklyReport {
	public static Weekly_Report_Entity week_rep = new Weekly_Report_Entity();

	public static void ShowByDate(String inputQuery){
		ArrayList <String> data = new ArrayList<String>();
		String [] dataDB;
		
		data=jdbc.mysqlConnection.ActionMode(inputQuery.toString());
		if(data.isEmpty())
			JOptionPane.showMessageDialog(null,"Please insert a date.", "Date Error", JOptionPane.ERROR_MESSAGE);
		else
		{
			dataDB=data.get(0).split(",");
			System.out.println("start it");
			for(String item: dataDB)
				System.out.println(item);
			System.out.println("end it");
			week_rep.setAVGWaitingTimeForAppointment(Float.parseFloat(dataDB[2]));
		}
	}
	
	
	public static void ClinicDetails(String inputQuery){
		ArrayList <String> data = new ArrayList<String>();
		data=jdbc.mysqlConnection.ActionMode(inputQuery.toString());
		String[] clinicName = new String[data.size()];
		int[] clinicNum = new int[data.size()];
		String[] strSplit;
		
		for(int i=0; i<data.size(); i++)	// for each line in table
		{
			strSplit = data.get(i).split(",");
			for(int j=0; j<strSplit.length; j++)
				System.out.print(j + ": " + strSplit[j] + " ~ ");
			System.out.println();
		}
	}
}
