package controllers;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import javax.swing.JOptionPane;

import Entitys.patient;
import Entitys.Appointment;


public class AppointmentControllers {
	public static Appointment app=new  Appointment();
	public void getNewAppointment_num()
	{
		String quary;
		ArrayList<String> data = new ArrayList<String>();
		quary="pull:appointments";
		data=jdbc.mysqlConnection.ActionMode(quary);
		int Appointment_num=data.size();
		Appointment_num++;
		app.setAppointment_num(Appointment_num);
	}

	public static boolean CurrentAppointment(Appointment app)
	{
		String [] parts = null;
		String quary;
		Calendar cal;
		ArrayList<String> data = new ArrayList<String>();
		quary="pull:appointments";
		data=jdbc.mysqlConnection.ActionMode(quary);
		if(data==null) return false;
		else
			{
			

			Date today=new Date();
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd") ;
			String currDate=sdf.format(today);
			cal=Calendar.getInstance();
			cal.setTime(today);

			for(int i=0;i<data.size();i++){
			parts=data.get(i).split(",");
			if(Integer.toString(cal.get(Calendar.HOUR_OF_DAY)).equals(parts[7]) && currDate.equals(parts[6]))
				{
				System.out.println("\nhour "+cal.get(Calendar.HOUR_OF_DAY));
				System.out.println("\ndate "+currDate);
				app.setApp_date(parts[6]);
				app.setApp_hour(Integer.parseInt(parts[7]));
				app.setAppointment_num( Integer.parseInt(parts[1]));
				app.setCall_date(parts[8]);
				app.setClinic_num(Integer.parseInt(parts[3]));
				app.setReferral_num(Integer.parseInt(parts[2]));
				app.setWorker_num(Integer.parseInt(parts[4]));
				}
			 }
			}
			return true;
	}
	
	public static void updateArrived(String inputQuery)
	{
		jdbc.mysqlConnection.ActionMode(inputQuery.toString());
	}

}
