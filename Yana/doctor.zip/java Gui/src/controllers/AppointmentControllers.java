package controllers;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import javax.swing.JOptionPane;
import Entitys.patient;
import Entitys.patient;
import Entitys.Appointment;


public class AppointmentControllers {
	/**name: getNewAppointment_num
	 * input: Appointment type app*/
	public void getNewAppointment_num(Appointment app)
	{
		String quary;
		ArrayList<String> data = new ArrayList<String>();
		quary="pull:appointments";
		data=jdbc.mysqlConnection.ActionMode(quary);
		int Appointment_num=data.size();
		Appointment_num++;
		app.setAppointment_num(Appointment_num);
	}

	public static boolean CurrentAppointment(Appointment app,patient tempinfo,String input)
	{
		String [] parts = null;
		String quary;
		String quaryPatient;
		Calendar cal;
		String [] partsPatient = null;
		ArrayList<String> data = new ArrayList<String>();
		ArrayList<String> dataPatient = new ArrayList<String>();
		quary="pull:appointments";
		data=jdbc.mysqlConnection.ActionMode(quary);
		if(data==null) return false;
		else
			{
			quaryPatient="pullBykey:patients:Person_id,"+input;
			dataPatient=jdbc.mysqlConnection.ActionMode(quaryPatient);
			if(dataPatient==null)
			{
				JOptionPane.showMessageDialog(null,"No insurence info was found", "patient",JOptionPane.ERROR_MESSAGE);
				
				tempinfo.setInsurance_level(-1);
				tempinfo.setInsurance_validity(-1);
				return true;
			}
		else
			{
			partsPatient=dataPatient.toString().split(",");

			}

			Date today=new Date();
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd") ;
			String currDate=sdf.format(today);
			cal=Calendar.getInstance();
			cal.setTime(today);

			for(int i=0;i<data.size();i++){
			parts=data.get(i).split(",");
			if(Integer.toString(cal.get(Calendar.HOUR_OF_DAY)).equals(parts[7]) && currDate.equals(parts[6]))
				{
				System.out.println("\nhour "+cal.get(Calendar.HOUR_OF_DAY));
				System.out.println("\ndate "+currDate);
				app.setApp_date(parts[6]);
				app.setApp_hour(Integer.parseInt(parts[7]));
				app.setAppointment_num( Integer.parseInt(parts[1]));
				app.setCall_date(parts[8]);
				app.setClinic_num(Integer.parseInt(parts[3]));
				app.setReferral_num(Integer.parseInt(parts[2]));
				app.setWorker_num(Integer.parseInt(parts[4]));
				app.setPatientNum(Integer.parseInt(parts[10]));
					if(dataPatient!=null)
					{
						tempinfo.setPatient_num(Integer.parseInt(partsPatient[1]));
						tempinfo.setInsurance_level(Integer.parseInt(partsPatient[3]));
						tempinfo.setInsurance_validity(Integer.parseInt(partsPatient[4]));
					}
				
				}
			 }
			return true;
			}
			
	}
	
	public static void updateArrived(String inputQuery)
	{
		jdbc.mysqlConnection.ActionMode(inputQuery.toString());
	}
	

	

}
