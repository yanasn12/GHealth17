package controllers;

import java.util.ArrayList;

import javax.swing.JOptionPane;

import Entitys.Daily_Report_Entity;

public class DailyReportController {
	private static boolean toContinue = true;
	public static Daily_Report_Entity dailyRepEnt = new Daily_Report_Entity();
	
	
	public static void InsertDailyDetailsToDB(String inputQuery){
		if(toContinue)
			jdbc.mysqlConnection.ActionMode(inputQuery.toString());
	}
	
	public static void ClacDailyDetails(String inputQuery){
		ClacPatientsAmount(inputQuery);
		if(toContinue)
		{
			CalcPatientsMonths(inputQuery);
			//dailyRepEnt.SetClinicNum(val);
			//setClinicNum
		}
	}
	
	public static void ClacPatientsAmount(String inputQuery){
		ArrayList <String> data = new ArrayList<String>();
		
		data=jdbc.mysqlConnection.ActionMode(inputQuery.toString());
		
		if(data.isEmpty())
		{
			toContinue = false;
			dailyRepEnt.InitAll();
			JOptionPane.showMessageDialog(null,"No appointments for this date.", "Date Error", JOptionPane.ERROR_MESSAGE);
		}
		else
		{
			toContinue = true;
			dailyRepEnt.SetPatientsAmount(data.size());
		}
	}
	
	
	public static void CalcPatientsMonths(String inputQuery){
		ArrayList <String> data = new ArrayList<String>();
		String [] dataDB, app, call;
		int day, month, year;
		
		data=jdbc.mysqlConnection.ActionMode(inputQuery.toString());
		if(data.isEmpty())
			JOptionPane.showMessageDialog(null,"you have enter a wrong Username.", "Login Error",JOptionPane.ERROR_MESSAGE);
		else
		{
			for (String item : data)
			{
				dataDB=item.split(",");
				app = dataDB[6].split("-"); // app[0]=year, app[1]=mm, app[2]=dd
				call = dataDB[8].split("-"); // call[0]=year, call[1]=mm, call[2]=dd
				day =  Integer.valueOf(app[2]) - Integer.valueOf(call[2]);
				month = Integer.valueOf(app[1]) - Integer.valueOf(call[1]);
				year = Integer.valueOf(app[0]) - Integer.valueOf(call[0]);
				
				if (day < 0 && month > 0)
					month-- ;
				
				switch (month) {
				case 0: dailyRepEnt.IncWaiting_month_0();
						break;
				case 1: dailyRepEnt.IncWaiting_month_1();
						break;
				case 2: dailyRepEnt.IncWaiting_month_2();
						break;
				default: dailyRepEnt.IncWaiting_month_3();
				}
			}
		}// Else
	}// CalcPatientsMonths
}
