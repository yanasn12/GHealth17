package controllers;

import java.util.ArrayList;

import javax.swing.JOptionPane;

import Entitys.patient;

public class Doctor {
	public static boolean iDInfo(String input, patient tempinfo)
	{
	String [] parts;
	String quary;
	ArrayList<String> data = new ArrayList<String>();
	quary="pullbykey:people:person_id,"+input;
	data=jdbc.mysqlConnection.ActionMode(quary);
	if(data==null)
		{
			return false;
		}
	else
		{
		parts=data.toString().split(",");
		tempinfo.setPerson_id(parts[1]);
		tempinfo.setFirst_name(parts[2]);
		tempinfo.setLast_name(parts[3]);
		tempinfo.setAddress(parts[4]);
		tempinfo.setEmail(parts[5]);
		tempinfo.setPhone(parts[6]);
		tempinfo.setBirth_date(parts[7]);
		}
	quary="pullBykey:patients:Person_id,"+input;
	data=jdbc.mysqlConnection.ActionMode(quary);
	if(data==null)
		{
			JOptionPane.showMessageDialog(null,"No insurence info was found", "patient",JOptionPane.ERROR_MESSAGE);
			tempinfo.setInsurance_level("-1");
			tempinfo.setInsurance_validity("-1");
			return true;
		}
	else
		{
			parts=data.toString().split(",");
			tempinfo.setInsurance_level(parts[3]);
			tempinfo.setInsurance_validity(parts[4]);
		}
	return true;
	}
}
