package controllers;

import java.util.ArrayList;

import javax.swing.JOptionPane;

import Entitys.patient;

public class Doctor {
	/**name: iDInfo
	 * input: string that contains person id ,entity
	 * output: if the database returns values the function return true otherwise false
	 * the function gets the data from the database, splits it to the fields, if the patient doesn't have insurance the the function shows message.
	 * the function saves the person's details*/
	public static boolean iDInfo(String input, patient tempinfo)
	{
	String [] parts;	/**parts array saves the splitted details from the data base*/
	String quary;		/**string quary saves the info to insert to DB*/
	ArrayList<String> data = new ArrayList<String>();/** data ArrayList is a date from the database*/
	quary="pullbykey:people:person_id,"+input; 
	data=jdbc.mysqlConnection.ActionMode(quary);
	if(data==null)
		{
			return false;
		}
	else
		{
		parts=data.toString().split(",");
		tempinfo.setPerson_id(parts[1]);
		tempinfo.setFirst_name(parts[2]);
		tempinfo.setLast_name(parts[3]);
		tempinfo.setAddress(parts[4]);
		tempinfo.setEmail(parts[5]);
		tempinfo.setPhone(parts[6]);
		tempinfo.setBirth_date(parts[7]);
		}
	quary="pullBykey:patients:Person_id,"+input;
	data=jdbc.mysqlConnection.ActionMode(quary);
	if(data==null)
		{
			JOptionPane.showMessageDialog(null,"No insurence info was found", "patient",JOptionPane.ERROR_MESSAGE);
			
			tempinfo.setInsurance_level(-1);
			tempinfo.setInsurance_validity(-1);
			return true;
		}
	else
		{
			parts=data.toString().split(",");
			tempinfo.setPatient_num(Integer.parseInt(parts[1]));
			tempinfo.setInsurance_level(Integer.parseInt(parts[3]));
			tempinfo.setInsurance_validity(Integer.parseInt(parts[4]));
		}
	return true;
	}
}
