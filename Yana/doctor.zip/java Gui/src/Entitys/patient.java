package Entitys;

import java.util.ArrayList;

import controllers.Dispatcher;

public class patient {

/**full patient data*/
private int patient_num;
private String person_id;
private int insurance_level;
private int insurance_validity;
private int medical_file_num;
private String extensive_clinic_email;
private String first_name;
private String last_name;
private String address;
private String email;
private String phone;
private String birth_date;
private String references_file_num;
private String experieCodeInNeed;
private static String doctor_info;

private static	ArrayList<String> Doctor =new ArrayList<String>();
public static String [] DoctorToArray;

private static	ArrayList<String> Time_Palce_time =new ArrayList<String>();
public static String [] DateToArray= {"Date to be select"};
public static String [] PlaceAndTimeToArray;

public void newClient()
{
	patient_num=patientcount;
	patientcount++;
}

public static boolean MakeAppointment(String getDate,String getplaceAndTime)
{
	boolean status=true;
	String info = getDate+","+getplaceAndTime.split("-")[0]+","+getplaceAndTime.split("-")[1]+","+doctor_info.split(",")[1];
	if(Dispatcher.setAppointment(info)==true)
		status=true;
	else
		status=false;
	
return status;
}


public static void reload()
{
	String temp="Doctor to be select";
	DoctorToArray = new String [Doctor.size()+1];
	for(int i=1; i<(DoctorToArray.length) ;i++)
	{
		DoctorToArray[i]=Doctor.get(i-1).toString().split(",")[0];
	}
	DoctorToArray[0]=temp;
}

public static void reloadTime()
{
	String temp= DateToArray[0];
	DateToArray = new String [Time_Palce_time.size()+1];
	int newsize=0;
	String [] newdata ;
	for(int i=1; i<(DateToArray.length) ;i++)
	{
		DateToArray[i]=Time_Palce_time.get(i-1).toString().split(",")[0];
	}
	DateToArray[0]=temp;

	for(int i=0; i<DateToArray.length;i++)
	{
		if(DateToArray[i]!=null)
			if(!DateToArray[i].toString().equals("X") )
				for(int j=(i+1);j<DateToArray.length;j++)
			{
				
				if(DateToArray[i].equals(DateToArray[j])&& DateToArray[i]!=null)
					DateToArray[j]="X";
				if(DateToArray[j]==null)
					DateToArray[j]="X";
			}	
	}
	//-->
	DateToArray[0]=temp;
	for(int i=0;i<DateToArray.length;i++)
	{
		if(!DateToArray[i].equals("X"))
		{
			newsize++;
		}
	}
	newdata=new String [newsize];
	int place=0;
	for(int i=0;i<DateToArray.length;i++)
	{
		if(!DateToArray[i].equals("X"))
		{
			newdata[place]=DateToArray[i];
			place++;
		}
	}
	DateToArray=newdata;
}




public static void reloadByDate(String Date)
	{
	String [] newdata;

	PlaceAndTimeToArray = new String[Time_Palce_time.size()];
	int k=0;
		for(int i=1; i<(Time_Palce_time.size());i++)
			{
				if(Date.equals(Time_Palce_time.get(i).toString().split(",")[0]))
				{
					PlaceAndTimeToArray[k]=Time_Palce_time.get(i-1).toString().split(",")[1];
					k++;
				}
			}
		
		for(int i=0; i<PlaceAndTimeToArray.length;i++)
		{
			if(PlaceAndTimeToArray[i].toString()!=null)
			 if(!PlaceAndTimeToArray[i].toString().equals("X") )
				for(int j=(i+1);j<PlaceAndTimeToArray.length;j++)
				{
					
					if(PlaceAndTimeToArray[i].equals(PlaceAndTimeToArray[j])&& PlaceAndTimeToArray[i]!=null)
						PlaceAndTimeToArray[j]="X";
					if(PlaceAndTimeToArray[j]==null)
						PlaceAndTimeToArray[j]="X";
				}	
		}
		int newsize=0;
		for(int i=0;i<PlaceAndTimeToArray.length;i++)
		{
			if(!PlaceAndTimeToArray[i].equals("X"))
			{
				newsize++;
			}
		}
		newdata=new String [newsize];
		int place=0;
		for(int i=1;i<PlaceAndTimeToArray.length;i++)
		{
			if(!PlaceAndTimeToArray[i].equals("X"))
			{
				newdata[place]=PlaceAndTimeToArray[i];
				place++;
				
			}
		}
		PlaceAndTimeToArray=null;
		PlaceAndTimeToArray= new String[newdata.length];
		PlaceAndTimeToArray=newdata;

	}




private static boolean find (String [] liststr, String newstr,int placeInLine)
{
	if(placeInLine!=1)
	{
		for(int i=1; i<=placeInLine;i++)
		{
			if(liststr[i]!=null)
				if(liststr[i].equals(newstr))
					return false;
		}
	}
	return true;

}

/**gettring and setring*/
public static ArrayList<String> getTime_Palce_time() {
	return Time_Palce_time;
}

public static void setTime_Palce_time(ArrayList<String> time_Palce_time) {
	Time_Palce_time = time_Palce_time;
}

public static ArrayList<String> getDoctor() {
	return Doctor;
}

public static void setDoctor(ArrayList<String> doctor) {
	Doctor = doctor;
}


public String getExperieCodeInNeed() {
	return experieCodeInNeed;
}


public void setExperieCodeInNeed(String experieCodeInNeed) {
	this.experieCodeInNeed = experieCodeInNeed;
}


public String getReferences_file_num() {
	return references_file_num;
}


public void setReferences_file_num(String references_file_num) {
	this.references_file_num = references_file_num;
}

public String getReferral_num() {
	return referral_num;
}

public void setReferral_num(String referral_num) {
	this.referral_num = referral_num;
}
private String referral_num;

public static int patientcount=0;



public int getPatient_num() {
	return patient_num;
}
public void setPatient_num(int patient_num) {
	this.patient_num = patient_num;
}
public String getPerson_id() {
	return person_id;
}
public void setPerson_id(String person_id) {
	this.person_id = person_id;
}
public int getInsurance_level() {
	return insurance_level;
}
public void setInsurance_level(int insurance_level) {
	this.insurance_level = insurance_level;
}
public int getInsurance_validity() {
	return insurance_validity;
}
public void setInsurance_validity(int insurance_validity) {
	this.insurance_validity = insurance_validity;
}
public int getMedical_file_num() {
	return medical_file_num;
}
public void setMedical_file_num(int medical_file_num) {
	this.medical_file_num = medical_file_num;
}
public String getExtensive_clinic_email() {
	return extensive_clinic_email;
}
public void setExtensive_clinic_email(String extensive_clinic_email) {
	this.extensive_clinic_email = extensive_clinic_email;
}
public String getFirst_name() {
	return first_name;
}
public void setFirst_name(String first_name) {
	this.first_name = first_name;
}
public String getLast_name() {
	return last_name;
}
public void setLast_name(String last_name) {
	this.last_name = last_name;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
public String getBirth_date() {
	return birth_date;
}
public void setBirth_date(String birth_date) {
	this.birth_date = birth_date;
}

public String getDoctor_info() {
	return doctor_info;
}

public void setDoctor_info(String doctor_info) {
	this.doctor_info = doctor_info;
}


}
