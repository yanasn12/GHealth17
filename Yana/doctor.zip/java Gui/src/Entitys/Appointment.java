package Entitys;
import controllers.AppointmentControllers;

public class Appointment {

	private int appointment_num;
	private int referral_num;
	private int clinic_num;
	private int worker_num;
	private String status;
	private String app_date;
	private int app_hour;
	private String call_date;
	private String results;
	private int patient_num;
	
	public int getAppointment_num(){return appointment_num;}
	public int getReferral_num(){return referral_num;}
	public int getClinic_num(){return clinic_num;}
	public int getWorker_num(){return worker_num;}
	public String getStatus(){return status;}
	public String getApp_date(){return app_date;}
	public int getApp_hour(){return app_hour;}
	public String getCall_date(){return call_date;}
	public String getResults(){return results;}
	public int getPatientNum(){return patient_num;}
	public void setAppointment_num(int appointment_num) {this.appointment_num = appointment_num;}
	public void setReferral_num(int referral_num) {this.referral_num = referral_num;}
	public void setClinic_num(int clinic_num) {this.clinic_num = clinic_num;}
	public void setWorker_num(int worker_num) {this.worker_num = worker_num;}
	public void setApp_hour(int app_hour) {this.app_hour = app_hour;}
	public void setStatus(String status) {this.status = status;}
	public void setApp_date(String app_date) {this.app_date = app_date;}
	public void setCall_date(String call_date) {this.call_date = call_date;}
	public void setResults(String status) {this.results = results;}
	public void setPatientNum(int patient_num){this.patient_num = patient_num;}
}
