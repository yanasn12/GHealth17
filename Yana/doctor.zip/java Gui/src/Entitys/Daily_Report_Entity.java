package Entitys;

public class Daily_Report_Entity {
	private int clinic_num; // Primary??	// VV
	private String date;	// VV
	private String day_name;
	private int patients_amount;
	private float waiting_time_avg;
	private int waiting_time_max;	// days amount
	private int waiting_time_min;
	private int waiting_time_deviation;
	private int waiting_month_0;
	private int waiting_month_1;
	private int waiting_month_2;
	private int waiting_month_3;
	
	public Daily_Report_Entity(){
		InitAll();
	}
	

	public void InitAll(){
		day_name = "Sunday";
		patients_amount = 0;
		waiting_time_avg = 0;
		waiting_time_max = 0;
		waiting_time_min = 0;
		waiting_time_deviation = 0;
		waiting_month_0 = 0;
		waiting_month_1 = 0;
		waiting_month_2 = 0;
		waiting_month_3 = 0;
	}
	
	// Get
	public int GetClinicNum(){
		return this.clinic_num;
	}
	
	public String GetDate(){
		return this.date;
	}
	
	public String GetDayName(){
		return this.day_name;
	}

	public int GetPatientsAmount(){
		return this.patients_amount;
	}

	public float GetWaitingTimeAvg(){
		return this.waiting_time_avg;
	}

	public int GetWaitingTimeMax(){
		return this.waiting_time_max;
	}

	public int GetWaitingTimeMin(){
		return this.waiting_time_min;
	}
	
	public int GetWwaitingTimeDeviation(){
		return this.waiting_time_deviation;
	}
	
	public int GetWaiting_month_0(){
		return this.waiting_month_0;
	}

	public int GetWaiting_month_1(){
		return this.waiting_month_1;
	}

	public int GetWaiting_month_2(){
		return this.waiting_month_2;
	}
	
	public int GetWaiting_month_3(){
		return this.waiting_month_3;
	}

	// Set	
	public void SetClinicNum(int val){
		this.clinic_num = val;
	}

	public void SetDate(String date){
		this.date = date;
	}
	
	public void SetDayName(String name){
		this.day_name = name;
	}

	public void SetPatientsAmount(int val){
		this.patients_amount = val;
	}

	public void SetWaitingTimeAvg(float val){
		this.waiting_time_avg = val;
	}

	public void SetWaitingTimeMax(int val){
		this.waiting_time_max = val;
	}

	public void SetWaitingTimeMin(int val){
		this.waiting_time_min = val;
	}
	
	public void SetWwaitingTimeDeviation(int val){
		this.waiting_time_deviation = val;
	}
	
	public void SetWaiting_month_0(int val){
		this.waiting_month_0 = val;
	}

	public void SetWaiting_month_1(int val){
		this.waiting_month_1 = val;
	}

	public void SetWaiting_month_2(int val){
		this.waiting_month_2 = val;
	}

	public void SetWaiting_month_3(int val){
		this.waiting_month_3 = val;
	}
	
	//Inc
	public void IncWaiting_month_0(){
		this.waiting_month_0++;
	}

	public void IncWaiting_month_1(){
		this.waiting_month_1++;
	}

	public void IncWaiting_month_2(){
		this.waiting_month_2++;
	}

	public void IncWaiting_month_3(){
		this.waiting_month_3++;
	}
}
