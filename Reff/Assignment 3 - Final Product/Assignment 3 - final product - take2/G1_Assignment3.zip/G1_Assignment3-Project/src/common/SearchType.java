package common;
/**
 * 
 * This enum represents a search criteria for the Data Base
 *
 */
public enum SearchType { DEFAULT ,CUSTOMER, INVOICE, CAR, LOCATION, USER_TYPE, PERIDOIC_DISCOUNT_TEMPLATE, 
	FUEL_TYPE, FUEL_STOCK, REPORT, PERIODIC_DISCOUNT;
}
