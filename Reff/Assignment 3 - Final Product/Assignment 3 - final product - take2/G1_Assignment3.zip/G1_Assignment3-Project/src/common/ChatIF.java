
package common;
/**
 * 
 * Defines the implementing class as an interface for presenting server messages
 *
 */
public interface ChatIF 
{
  public abstract void display(String message);

}
